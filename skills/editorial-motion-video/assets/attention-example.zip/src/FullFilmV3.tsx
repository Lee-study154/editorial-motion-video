import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FullFilm} from './FullFilm';
import {FullCaptions} from './full/FullCaptions';
import {OutroScenesV3} from './full/ending-v3/OutroScenesV3';

export const FullFilmV3 = ({shutterOffset = 0}: {shutterOffset?: number}) => {
  const frame = useCurrentFrame();
  if (frame < 1092) return <FullFilm />;
  return <AbsoluteFill style={{background: '#FCFCFB', color: '#12171E', overflow: 'hidden',
    fontFamily: 'Arial, Helvetica, sans-serif'}}>
    <OutroScenesV3 frame={Math.max(1092, Math.min(1295, frame + shutterOffset))} />
    <FullCaptions />
  </AbsoluteFill>;
};
