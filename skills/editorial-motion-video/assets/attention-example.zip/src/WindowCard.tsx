import type {CSSProperties} from 'react';
import {Easing, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';

export type WindowSpec = {
  id: string;
  title: string;
  src: string;
  imageWidth: number;
  imageHeight: number;
  x: number;
  y: number;
  width: number;
  rotation: number;
  tilt: number;
  start: number;
  exitX: number;
  exitY: number;
};

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const blue = '#002FA7';
const power1Out = (value: number) => 1 - Math.pow(1 - value, 2);
const backOut = (amount: number) => (value: number) => {
  const x = value - 1;
  return 1 + (amount + 1) * x * x * x + amount * x * x;
};

// TalkCraft media-pop-in: scale .8→1, pre-tilt recovery, half-duration
// opacity, back.out and staggered evidence layers. Browser chrome,
// perspective, hero focus and side/back exits are specific to this opener.
export const WindowCard = ({
  spec,
  index,
  focus,
}: {
  spec: WindowSpec;
  index: number;
  focus: number;
}) => {
  const frame = useCurrentFrame();
  const main = spec.id === 'katherine';
  const pop = interpolate(frame, [spec.start, spec.start + 8], [0, 1], {
    ...clamp,
    easing: backOut(0.95),
  });
  const leave = main ? 0 : interpolate(frame, [54, 72], [0, 1], {
    ...clamp,
    easing: Easing.bezier(0.45, 0, 0.7, 1),
  });
  const width = main ? interpolate(focus, [0, 1], [spec.width, 888]) : spec.width;
  const imageHeight = width * spec.imageHeight / spec.imageWidth;
  const highlight = interpolate(frame, [64, 71], [0, 1], clamp);
  const x = main ? interpolate(focus, [0, 1], [spec.x, 96]) : spec.x;
  const y = main ? interpolate(focus, [0, 1], [spec.y, 430]) : spec.y;
  const markStyle: CSSProperties = {
    position: 'absolute',
    background: '#4270FF25',
    borderBottom: `6px solid ${blue}`,
    boxSizing: 'border-box',
    transformOrigin: 'left center',
    scale: `${highlight} 1`,
    opacity: highlight,
  };

  if (frame < spec.start || frame >= 98) return null;

  return (
    <div
      data-window={spec.id}
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width,
        zIndex: index + 1,
        translate: `${spec.exitX * leave}px ${
          (1 - pop) * 52 + spec.exitY * leave
        }px`,
        scale: (0.8 + 0.2 * pop) * (1 - 0.2 * leave),
        rotate: `${(spec.rotation - 6 * (1 - pop)) * (1 - focus * Number(main))
          + Math.sign(spec.exitX) * 8 * leave}deg`,
        transform: `translateZ(${-320 * leave}px) rotateY(${
          spec.tilt * (1 - focus * Number(main))
          - Math.sign(spec.exitX) * 15 * leave
        }deg) rotateX(${main ? 2.5 * (1 - focus) : 0}deg)`,
        transformOrigin: '50% 60%',
        opacity: interpolate(frame, [spec.start, spec.start + 4], [0, 1], {
          ...clamp,
          easing: power1Out,
        }) * interpolate(leave, [0, 0.6, 1], [1, 0.55, 0]),
        border: '1px solid #D4DAE3',
        borderRadius: 18,
        backgroundColor: '#FFFFFF',
        overflow: 'hidden',
        backfaceVisibility: 'hidden',
        boxShadow: `0 ${24 + 8 * pop}px ${48 + 8 * pop}px -18px #172D493D,
          0 4px 12px -4px #172D4912`,
      }}
    >
      <div style={{
        height: 48,
        boxSizing: 'border-box',
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '0 20px',
        background: '#F4F5F7',
        borderBottom: '1px solid #E0E4EB',
      }}>
        {[0, 1, 2].map((dot) => (
          <span key={dot} style={{
            width: 8, height: 8, borderRadius: '50%',
            border: '1px solid #A6AEBA', flexShrink: 0,
          }} />
        ))}
        <span style={{
          fontSize: 17, color: '#637083', letterSpacing: 0.25,
          marginLeft: 13, whiteSpace: 'nowrap', overflow: 'hidden',
          textOverflow: 'ellipsis',
        }}>{spec.title}</span>
      </div>
      <div style={{position: 'relative', height: imageHeight, background: '#FFF'}}>
        <Img src={staticFile(spec.src)} alt={spec.title} style={{
          display: 'block', width: '100%', height: '100%', objectFit: 'contain',
        }} />
        {main && <>
          {/* Native screenshot coordinates: 大 ends a line, 水 starts the next. */}
          <div style={{...markStyle, left: '90%', top: '35.8%', width: '5.6%', height: '6.2%'}} />
          <div style={{...markStyle, left: '1.8%', top: '41.8%', width: '4.9%', height: '6.2%'}} />
        </>}
      </div>
    </div>
  );
};
