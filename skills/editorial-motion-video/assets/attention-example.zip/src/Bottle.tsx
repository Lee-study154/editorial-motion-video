import {Easing, interpolate, spring, useCurrentFrame} from 'remotion';

const blue = '#002FA7';
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const body = 'M430 175 H650 V245 Q650 290 710 340 V1000 Q710 1045 665 1045 H415 Q370 1045 370 1000 V340 Q430 290 430 245 Z';

export const Bottle = () => {
  const frame = useCurrentFrame();
  // Match the design-frame clock used by the opening and its 60-fps wrapper.
  const fps = 30;
  const local = frame - 91;
  const cap = interpolate(local, [0, 6], [0, 1], {...clamp, easing: Easing.inOut(Easing.quad)});
  const outline = interpolate(local, [0, 18], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const detail = interpolate(local, [14, 24], [0, 1], clamp);
  const water = interpolate(local, [15, 27], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const tag = spring({frame: local - 23, fps, config: {damping: 20, stiffness: 180, mass: 0.75}});

  if (local < 0) return null;

  return (
    <svg
      viewBox="0 0 1080 1160"
      aria-label="A line-drawn two-litre water bottle with a THEORY question tag"
      style={{position: 'absolute', left: 0, top: 350, width: 1080, height: 1160}}
    >
      <defs>
        <clipPath id="opener-bottle-inside"><path d={body} /></clipPath>
        <filter id="opener-tag-shadow" x="-30%" y="-70%" width="170%" height="240%">
          <feDropShadow dx="0" dy="9" stdDeviation="9" floodColor="#19304C" floodOpacity="0.08" />
        </filter>
      </defs>
      <ellipse cx="542" cy="1083" rx={230 * outline} ry="20" fill="#E8EBF1" opacity={outline * 0.7} />
      <g clipPath="url(#opener-bottle-inside)">
        <g transform={`translate(0 ${330 * (1 - water)})`} opacity={water}>
          <path d="M365 720 Q460 690 550 720 T720 720 V1050 H365 Z" fill="#E3EBFF" />
          <path d="M365 720 Q460 690 550 720 T720 720" fill="none" stroke={blue} strokeWidth="3" />
        </g>
      </g>
      <g fill="none" stroke={blue} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round">
        <path d={body} opacity={interpolate(local, [0, 6], [0, 0.16], clamp) * (1 - outline)} />
        <rect x="425" y="105" width="230" height="70" rx="13"
          pathLength="1" strokeDasharray="1" strokeDashoffset={1 - cap} opacity={cap > 0 ? 1 : 0} />
        <path d={body} pathLength="1" strokeDasharray="1" strokeDashoffset={1 - outline}
          opacity={outline > 0 ? 1 : 0} />
        <path d="M454 123 V157 M485 123 V157 M516 123 V157 M547 123 V157 M578 123 V157 M609 123 V157"
          strokeWidth="2" opacity={interpolate(local, [4, 9], [0, 1], clamp)} />
      </g>
      <g stroke={blue} strokeWidth="3" fill="none" opacity={detail}>
        <path d="M410 390 H445 M410 480 H430 M410 570 H445 M410 660 H430 M410 750 H445 M410 840 H430 M410 930 H445"
          pathLength="1" strokeDasharray="1" strokeDashoffset={1 - detail} />
      </g>
      <text x="485" y="590" fontSize="88" fill={blue} fontWeight="700" opacity={detail}>2L</text>
      <g transform={`translate(620 410) rotate(${10 - 13 * (1 - tag)})`}>
        <path d="M0 0 L115 8" fill="none" stroke="#26313E" strokeWidth="2"
          pathLength="1" strokeDasharray="1" strokeDashoffset={1 - Math.min(1, tag)}
          opacity={tag > 0 ? 1 : 0} />
        <g style={{
          opacity: interpolate(local, [23, 27], [0, 1], clamp),
          transform: `translate(${108 * (1 - tag)}px, ${-12 * (1 - tag)}px) scale(${0.86 + 0.14 * tag})`,
          transformOrigin: '108px 8px',
        }} filter="url(#opener-tag-shadow)">
          <rect x="108" y="-42" width="236" height="100" rx="5" fill="#FCFCFB" stroke="#26313E" strokeWidth="2" />
          <circle cx="124" cy="9" r="5" fill="none" stroke="#26313E" strokeWidth="2" />
          <text x="145" y="23" fill={blue} fontSize="33" fontWeight="700">THEORY?</text>
        </g>
      </g>
    </svg>
  );
};
