import {Easing, interpolate} from 'remotion';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const gentle = Easing.bezier(0.25, 0.1, 0.25, 1);
export const characterStage = {left: 226, top: 512, width: 1030, height: 1530, scale: 650 / 1030};
export const headPivot = {x: 477, y: 318};
export const armPivot = {x: 790, y: 510};
export const originalBadge = {x: 528.5, y: 450};

export const rotateAboutElbow = (x: number, y: number, angle: number) => {
  const rad = angle * Math.PI / 180;
  const dx = x - armPivot.x;
  const dy = y - armPivot.y;
  return {x: armPivot.x + dx * Math.cos(rad) - dy * Math.sin(rad),
    y: armPivot.y + dx * Math.sin(rad) + dy * Math.cos(rad)};
};

export const getCharacterPose = (frame: number) => {
  const armAngle = interpolate(frame, [299, 321, 351, 371], [0, -10, -10, 0], {...clamp, easing: gentle});
  return {
    armAngle,
    // One deliberate acknowledgement; the complete head and both pupils share this transform.
    headAngle: interpolate(frame, [299, 321, 351, 371, 377, 388, 401], [0, 1.8, 1.8, 1.2, 1.2, 3.8, 0], {...clamp, easing: gentle}),
    headY: interpolate(frame, [299, 321, 377, 388, 401], [0, 1, 1, 4, 0], {...clamp, easing: gentle}),
    gazeX: interpolate(frame, [299, 310, 321, 371, 390, 401], [-3, -1, 1, 0, -1, -2], {...clamp, easing: gentle}),
    gazeY: interpolate(frame, [299, 310, 321, 371, 390, 401], [-2, 0, 0, -1, -3, -4], {...clamp, easing: gentle}),
    badge: rotateAboutElbow(originalBadge.x, originalBadge.y, armAngle),
    reveal: interpolate(frame, [299, 322], [0, 1], clamp),
  };
};
