import type {ReactNode} from 'react';
import {Img, staticFile, useCurrentFrame} from 'remotion';
import {armPivot, characterStage, getCharacterPose, headPivot} from './CharacterMotion';

const layer = {position: 'absolute', left: 0, top: 0, width: 1030, height: 1530} as const;
const asset = (name: string) => staticFile(`body-enhanced/character-${name}.png`);

// The torso/feet stay stationary. Head, two pupils and the COMPLETE forearm/cuff/hand
// are separate source-pixel layers. Badge shares the same elbow transform after capture.
export const CharacterRig = ({badge}: {badge: ReactNode}) => {
  const frame = useCurrentFrame();
  const pose = getCharacterPose(frame);
  const reveal = {position: 'absolute', inset: 0,
    clipPath: `inset(0 0 ${100 * (1 - pose.reveal)}% 0)`,
  } as const;
  return <div style={{
    position: 'absolute', left: characterStage.left, top: characterStage.top,
    width: characterStage.width, height: characterStage.height,
    transform: `scale(${characterStage.scale})`, transformOrigin: '0 0',
  }}>
    <div style={reveal}>
      <Img src={asset('body')} style={layer} />
      <div style={{...layer, transformOrigin: `${headPivot.x}px ${headPivot.y}px`,
        transform: `translateY(${pose.headY}px) rotate(${pose.headAngle}deg)`,
      }}>
        <Img src={asset('head')} style={layer} />
        <div style={{...layer, maskImage: `url("${asset('eyes-mask')}")`, maskSize: '1030px 1530px',
          WebkitMaskImage: `url("${asset('eyes-mask')}")`, WebkitMaskSize: '1030px 1530px',
        }}>
          {['pupil-left', 'pupil-right'].map((name) => <Img key={name} src={asset(name)} style={{
            ...layer, translate: `${pose.gazeX}px ${pose.gazeY}px`,
          }} />)}
        </div>
      </div>
    </div>
    {badge}
    <div style={reveal}>
      <Img src={asset('arm')} style={{...layer,
        transformOrigin: `${armPivot.x}px ${armPivot.y}px`, transform: `rotate(${pose.armAngle}deg)`,
      }} />
    </div>
  </div>;
};
