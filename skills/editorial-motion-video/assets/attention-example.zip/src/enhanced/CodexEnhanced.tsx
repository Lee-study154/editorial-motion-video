import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {PageMagnifier, pageDetail} from './PageMagnifier';

// BodyCodex's actual tilt-3d-page adaptation is retained, with a single real detail event.
// Tilt source SHA256: 6abd2141e995365190923694201154d01adf0610482c20b1b868ef57f8343a6c.
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.bezier(0.16, 1, 0.3, 1);
const blue = '#002FA7';

export const CodexEnhanced = () => {
  const frame = useCurrentFrame();
  const {stage, dim} = pageDetail(frame);
  const dive = interpolate(frame, [0, 45], [0, 1], {...clamp, easing: ease});
  const contract = interpolate(frame, [146, 181], [0, 1], {
    ...clamp, easing: Easing.bezier(0.65, 0, 0.35, 1),
  });
  const readPush = 1 + 0.015 * interpolate(frame, [45, 146], [0, 1], clamp) * (1 - stage) * (1 - contract);
  const pageLeft = 150 - 60 * stage - 60 * contract;
  const pageTop = 218 + 878 * contract;
  const pageWidth = 780 - 150 * stage - 500 * contract;
  const pageHeight = 48 + (pageWidth - 4) * 766 / 598;
  return <AbsoluteFill style={{perspective: 1200, perspectiveOrigin: '50% 42%'}}>
    <div style={{
      position: 'absolute', left: 90, top: 108, display: 'flex', alignItems: 'center', gap: 16,
      color: '#697383', fontSize: 24, letterSpacing: 2.5,
      opacity: interpolate(frame, [0, 18, 143, 158], [0, 1, 1, 0], clamp),
    }}><span style={{width: 10, height: 10, background: blue, borderRadius: '50%'}} />X / @OPENAI / CODEX</div>
    <div style={{
      position: 'absolute', left: pageLeft, top: pageTop, width: pageWidth,
      height: pageHeight * (1 - contract) + 108 * contract,
      transformStyle: 'preserve-3d', transformOrigin: 'center center',
      transform: `translate3d(${-48 * (1 - dive)}px, ${45 * (1 - dive)}px, ${80 * (1 - dive)}px) rotateY(${-23 * (1 - dive)}deg) rotateX(${7 * (1 - dive)}deg) rotateZ(${-4 * (1 - dive)}deg) scale(${(1.05 - 0.05 * dive) * readPush})`,
    }}>
      <div style={{
        position: 'absolute', inset: 0, borderRadius: 17 + 37 * contract,
        background: '#172B4A', filter: 'blur(26px)',
        opacity: (0.18 - 0.12 * dive) * (1 - contract),
        transform: `translate3d(${28 * (1 - dive)}px, ${18 * (1 - dive) + 12}px, -34px)`,
      }} />
      <div style={{
        position: 'absolute', inset: 0, overflow: 'hidden', borderRadius: 17 + 37 * contract,
        background: '#FCFCFB', border: `2px solid ${contract > 0.8 ? '#C5CFDF' : '#D4DAE4'}`,
        backfaceVisibility: 'hidden', boxSizing: 'border-box',
      }}>
        <div style={{
          height: 43, padding: '0 19px', display: 'flex', alignItems: 'center', gap: 8,
          background: '#F4F5F7', borderBottom: '1px solid #DDE2EA', color: '#596474',
          fontSize: 16, letterSpacing: 0.6,
        }}>
          {[0, 1, 2].map((i) => <span key={i} style={{width: 7, height: 7, border: '1px solid #A4ADBA', borderRadius: '50%'}} />)}
          <span style={{marginLeft: 12}}>x.com / @OpenAI</span>
        </div>
        <Img src={staticFile('body/x-codex.jpg')} style={{display: 'block', width: '100%', filter: `brightness(${dim})`}} />
        <div style={{
          position: 'absolute', inset: 0, background: '#FCFCFB', display: 'flex', alignItems: 'center', justifyContent: 'center',
          opacity: interpolate(frame, [164, 178], [0, 1], clamp),
          fontSize: 37, fontWeight: 700, color: '#12171E',
        }}><span style={{opacity: interpolate(frame, [173, 181], [0, 1], clamp)}}>CODEX</span></div>
      </div>
    </div>
    <PageMagnifier frame={frame} pageLeft={pageLeft} pageTop={pageTop} pageWidth={pageWidth} />
    <div style={{
      position: 'absolute', left: 86, top: 1316, fontSize: 102, lineHeight: 0.98,
      letterSpacing: -5, fontWeight: 800,
      opacity: interpolate(frame, [89, 100, 142, 156], [0, 1, 1, 0], clamp),
      translate: `0px ${interpolate(frame, [89, 104], [29, 0], {...clamp, easing: ease})}px`,
    }}>ALREADY<br /><span style={{color: blue}}>BEHIND?</span></div>
  </AbsoluteFill>;
};
