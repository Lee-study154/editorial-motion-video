import {AbsoluteFill, Easing, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {BodySourceConverge} from '../BodySourceConverge';

// Wrapper only: the actual copied TalkCraft core is deliberately imported unchanged.
// See ../BodySourceConverge.tsx: a00163db942ec12861a243ad46e6b980804e8dd245cdcf5359b9bf06c5260673.
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = Easing.bezier(0.22, 1, 0.36, 1);
const cues = ['water', 'lean', 'codex'];

const SourceCues = () => {
  const frame = useCurrentFrame();
  if (frame < 169 || frame >= 199) return null;
  const fold = interpolate(frame, [185, 199], [0, 1], {...clamp, easing: ease});
  return <>{cues.map((cue, i) => {
    const y = [690, 920, 1150][i];
    const opacity = interpolate(frame, [169 + i * 2, 177 + i * 2, 189, 199], [0, 1, 1, 0], clamp);
    return <div key={cue} style={{
      position: 'absolute', left: 90, top: y + 62 - 114 * fold, width: 280, height: 104,
      transformOrigin: 'center center', scale: String(1 - 0.75 * fold), opacity,
      border: '1px solid #C5CFDF', borderRadius: 12 + 40 * fold, overflow: 'hidden',
      boxSizing: 'border-box', background: '#FCFCFB',
    }}><Img src={staticFile(`body-enhanced/page-${cue}-cue.png`)} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>;
  })}</>;
};

export const AttentionEnhanced = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill>
    <div style={{
      position: 'absolute', left: 90, top: 108, fontSize: 24, letterSpacing: 2.5,
      color: '#697383', display: 'flex', alignItems: 'center', gap: 16,
      opacity: interpolate(frame, [166, 179], [0, 1], clamp),
    }}><span style={{width: 10, height: 10, background: '#002FA7', borderRadius: '50%'}} />THE MECHANISM</div>
    <div style={{
      position: 'absolute', left: 86, right: 80, top: 224, fontSize: 91,
      lineHeight: 1.04, letterSpacing: -4.6, fontWeight: 800,
      opacity: interpolate(frame, [169, 181], [0, 1], clamp),
      translate: `0px ${interpolate(frame, [169, 187], [24, 0], {...clamp, easing: ease})}px`,
    }}>Different topics.<br />
      <span style={{color: '#002FA7', opacity: interpolate(frame, [221, 232], [0, 1], clamp)}}>Same business.</span>
    </div>
    <SourceCues />
    <BodySourceConverge />
  </AbsoluteFill>;
};
