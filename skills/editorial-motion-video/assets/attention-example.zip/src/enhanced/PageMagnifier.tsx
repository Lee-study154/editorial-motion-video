import {Img, staticFile} from 'remotion';

// Actual magnifier-detail CONFIG + animation/clone core, adapted to a real X image.
// Source SHA256: 59ca146586bf0f56826dd80e33edfb29c10a7da8cb31aa23a72bc28e49f1544b.
// Source pixels measured by references/derive-page-assets.py; no replacement text.
const TARGET = {px: 126.5, py: 180, left: 103, top: 174, w: 47, h: 12};
const CONFIG = {zoom: 1.8, magSize: 320, magX: 890, magY: 660, popIn: 0.3, dimTo: 0.6, startDelay: 2, panPx: 7};
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const tw = (t: number, t0: number, d: number, ease: (x: number) => number) => ease(clamp01((t - t0) / d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const power1Out = (x: number) => 1 - Math.pow(1 - x, 2);
const power2Out = (x: number) => 1 - Math.pow(1 - x, 3);
const power3Out = (x: number) => 1 - Math.pow(1 - x, 4);
const sineInOut = (x: number) => -(Math.cos(Math.PI * x) - 1) / 2;

export const pageDetail = (frame: number) => {
  const t = frame / 30;
  const stage = tw(t, 1.5, 14 / 30, power2Out) * (1 - tw(t, 126 / 30, 14 / 30, power2Out));
  const pop = tw(t, CONFIG.startDelay, CONFIG.popIn, power3Out);
  const exit = tw(t, 124 / 30, 12 / 30, power2Out);
  const visible = pop * (1 - exit);
  const dim = lerp(1, CONFIG.dimTo, tw(t, CONFIG.startDelay, 0.3, power1Out) * (1 - exit));
  return {stage, visible, dim, pop, exit};
};

type Props = {frame: number; pageLeft: number; pageTop: number; pageWidth: number};

export const PageMagnifier = ({frame, pageLeft, pageTop, pageWidth}: Props) => {
  const t = frame / 30;
  const C = CONFIG;
  const {visible, pop, exit} = pageDetail(frame);
  if (frame < 60 || frame >= 136) return null;
  // At 60–124f the page is upright, stage=1, scale=1. Border 2 + toolbar 44.
  const sourceScale = (pageWidth - 4) / 598;
  const px = TARGET.px * sourceScale, py = TARGET.py * sourceScale;
  const tx = pageLeft + 2 + px, ty = pageTop + 46 + py;
  const lineLen = Math.hypot(C.magX - tx, C.magY - ty);
  const dashTotal = Math.ceil(lineLen) + 10;
  const magScale = lerp(0.3, 1, pop) * lerp(1, 0.72, exit);
  const magX = lerp(tx, C.magX, pop), magY = lerp(ty, C.magY, pop);
  const lineP = tw(t, C.startDelay + C.popIn - 0.05, 0.25, power2Out);
  const boxOpacity = tw(t, C.startDelay, 0.2, power1Out) * (1 - exit);

  // Retain the upstream 1.4s half-cycle sine yoyo scan, after the line has appeared.
  const panT0 = C.startDelay + C.popIn + 0.2;
  let pan = 0;
  if (t > panT0) {
    const cyc = (t - panT0) / 1.4, k = Math.floor(cyc), p = cyc - k;
    pan = -C.panPx * C.zoom * sineInOut(k % 2 === 1 ? 1 - p : p);
  }
  const innerX = C.magSize / 2 - C.zoom * px + pan;
  const innerY = C.magSize / 2 - C.zoom * py;
  const box = {
    left: pageLeft + 2 + TARGET.left * sourceScale - 18,
    top: pageTop + 46 + TARGET.top * sourceScale - 18,
    width: TARGET.w * sourceScale + 36, height: TARGET.h * sourceScale + 36,
  };
  return <>
    <div style={{position: 'absolute', ...box, border: '2px solid #002FA7', borderRadius: 7,
      boxSizing: 'border-box', opacity: boxOpacity}} />
    <svg viewBox="0 0 1080 1920" style={{position: 'absolute', inset: 0, width: 1080, height: 1920, opacity: 1 - exit}}>
      <line x1={tx} y1={ty} x2={C.magX} y2={C.magY} stroke="#002FA7" strokeWidth="2"
        strokeDasharray={`${dashTotal * lineP} ${dashTotal * (1 - lineP)}`} />
    </svg>
    <div style={{position: 'absolute', left: magX - C.magSize / 2, top: magY - C.magSize / 2,
      width: C.magSize, height: C.magSize, borderRadius: '50%', border: '2px solid #12171E',
      overflow: 'hidden', background: '#000', boxSizing: 'border-box', opacity: visible,
      scale: String(magScale), transformOrigin: 'center'}}>
      <div style={{position: 'absolute', left: innerX, top: innerY,
        transform: `scale(${C.zoom})`, transformOrigin: '0 0'}}>
        <Img src={staticFile('body/x-codex.jpg')} style={{display: 'block', width: pageWidth - 4, maxWidth: 'none'}} />
      </div>
    </div>
  </>;
};
