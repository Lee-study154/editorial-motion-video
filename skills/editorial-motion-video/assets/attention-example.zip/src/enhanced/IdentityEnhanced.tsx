import {AbsoluteFill, Easing, Img, interpolate, interpolateColors, staticFile, useCurrentFrame} from 'remotion';
import {CharacterRig} from './CharacterRig';
import {armPivot, characterStage, getCharacterPose} from './CharacterMotion';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const BLUE = '#002FA7';
const INK = '#12171E';
const PAPER = '#FCFCFB';

export const IdentityEnhanced = () => {
  const frame = useCurrentFrame();
  const pose = getCharacterPose(frame);
  const s = characterStage.scale;
  const morph = interpolate(frame, [295, 321], [0, 1], {...clamp, easing: Easing.bezier(0.65, 0, 0.35, 1)});
  // At 295 the single incoming hub is exactly (540,920,r170), in stage coordinates.
  const bx = interpolate(morph, [0, 1], [(540 - characterStage.left) / s, pose.badge.x]);
  const by = interpolate(morph, [0, 1], [(920 - characterStage.top) / s, pose.badge.y]);
  const radius = interpolate(morph, [0, 1], [170 / s, 60]);
  const badge = <>
    {frame <= 321 && <>
      <div style={{
        position: 'absolute', left: bx - radius, top: by - radius, width: radius * 2, height: radius * 2,
        perspective: 1200 / s, perspectiveOrigin: '50% 50%',
      }}>
        <div style={{
          position: 'absolute', inset: 0, borderRadius: '50%',
          background: interpolateColors(frame, [310, 321], [BLUE, PAPER]),
          border: `${interpolate(frame, [310, 321], [0, 8], clamp)}px solid ${interpolateColors(frame, [310, 321], [BLUE, INK])}`,
          boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center',
          transform: `rotateY(${interpolate(frame, [295, 307, 321], [0, 22, 0], clamp)}deg)`,
        }}>
          <span style={{color: 'white', fontSize: 39 / s, fontWeight: 700, letterSpacing: -1 / s,
            opacity: interpolate(frame, [295, 307], [1, 0], clamp),
            scale: interpolate(morph, [0, 1], [1, 0.25]),
          }}>ATTENTION</span>
        </div>
      </div>
      <div style={{
        position: 'absolute', left: bx - 192 / s * (1 - morph), top: by - 192 / s * (1 - morph),
        width: 384 / s * (1 - morph), height: 384 / s * (1 - morph),
        border: `${2 / s}px solid ${BLUE}`, borderRadius: '50%', boxSizing: 'border-box',
        opacity: 0.12 * (1 - morph),
      }} />
    </>}
    {/* Disk and complete hand stay in one elbow coordinate system from capture to press. */}
    <div style={{position: 'absolute', left: 0, top: 0, width: 1030, height: 1530,
      transformOrigin: `${armPivot.x}px ${armPivot.y}px`, transform: `rotate(${pose.armAngle}deg)`,
      opacity: interpolate(frame, [315, 321], [0, 1], clamp),
    }}>
      <Img src={staticFile('body-enhanced/character-badge.png')} style={{
        position: 'absolute', left: 467, top: 390, width: 123, height: 120,
      }} />
    </div>
  </>;

  return <AbsoluteFill style={{fontFamily: 'Arial, Helvetica, sans-serif', color: INK}}>
    <div style={{position: 'absolute', inset: 0, background: PAPER,
      clipPath: `inset(0 ${interpolate(frame, [295, 304], [100, 0], clamp)}% 0 0)`,
    }} />
    <div style={{
      position: 'absolute', left: 90, top: 108, display: 'flex', alignItems: 'center', gap: 16,
      color: '#697383', fontSize: 24, letterSpacing: 2.5,
      clipPath: `inset(0 ${interpolate(frame, [299, 310], [100, 0], clamp)}% 0 0)`,
    }}><span style={{width: 10, height: 10, background: BLUE, borderRadius: '50%'}} />FROM HABIT TO IDENTITY</div>
    <div style={{
      position: 'absolute', left: 86, top: 226, fontSize: 91, lineHeight: 1.04,
      letterSpacing: -4.6, fontWeight: 800,
      clipPath: `inset(0 ${interpolate(frame, [299, 313], [100, 0], clamp)}% 0 0)`,
    }}>Give it a name.<br />
      {frame >= 351 && <span style={{color: BLUE}}>Make it you.</span>}
    </div>
    <CharacterRig badge={badge} />
  </AbsoluteFill>;
};
