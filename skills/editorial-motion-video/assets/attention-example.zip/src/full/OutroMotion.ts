// Private deterministic helpers. Curve lookup is copied from TalkCraft source-converge;
// see production/full-film/references/outro-provenance.json for original source SHA.
export const PAPER = '#FCFCFB';
export const INK = '#12171E';
export const BLUE = '#002FA7';
export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
export const power1Out = (x: number) => 1 - (1 - x) ** 2;
export const power2Out = (x: number) => 1 - (1 - x) ** 3;
export const power2In = (x: number) => x ** 3;
export const power3Out = (x: number) => 1 - (1 - x) ** 4;
export const power2InOut = (x: number) => x < 0.5 ? 4 * x ** 3 : 1 - (-2 * x + 2) ** 3 / 2;
export const backOut = (s = 1.4) => (x: number) => {
  const t = x - 1;
  return 1 + (s + 1) * t ** 3 + s * t ** 2;
};
export const tw = (f: number, at: number, duration: number, ease = power2InOut) =>
  ease(clamp01((f - at) / duration));

type Pt = {x: number; y: number};
const cubic = (p0: number, p1: number, p2: number, p3: number, u: number) => {
  const v = 1 - u;
  return v * v * v * p0 + 3 * v * v * u * p1 + 3 * v * u * u * p2 + u * u * u * p3;
};
export function buildCurve(P: [Pt, Pt, Pt, Pt], N = 200) {
  const pts: Pt[] = [], cum: number[] = [0];
  for (let k = 0; k <= N; k++) {
    const u = k / N;
    pts.push({x: cubic(P[0].x, P[1].x, P[2].x, P[3].x, u), y: cubic(P[0].y, P[1].y, P[2].y, P[3].y, u)});
    if (k) cum.push(cum[k - 1] + Math.hypot(pts[k].x - pts[k - 1].x, pts[k].y - pts[k - 1].y));
  }
  const len = cum[N];
  const at = (L: number): Pt => {
    const q = Math.max(0, Math.min(len, L));
    let lo = 0, hi = N;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (cum[mid] <= q) lo = mid; else hi = mid;
    }
    const seg = cum[hi] - cum[lo] || 1, f = (q - cum[lo]) / seg;
    return {x: lerp(pts[lo].x, pts[hi].x, f), y: lerp(pts[lo].y, pts[hi].y, f)};
  };
  return {d: `M ${P[0].x},${P[0].y} C ${P[1].x},${P[1].y} ${P[2].x},${P[2].y} ${P[3].x},${P[3].y}`, len, at};
}
