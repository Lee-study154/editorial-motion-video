import {BLUE, INK, PAPER} from '../OutroMotion';
import {ease, morphRect, seg} from './OneTakeMotion';
import {cameraAt, detailLevel, PAGE, PAGE_SCALE} from './ScaleCamera';

export const NestedPage = ({frame}: {frame: number}) => {
  const lod = detailLevel(frame);
  const write = ease.expoOut(seg(frame, 1176, 1182));
  const block = morphRect(frame, 1194, 1212,
    {x: 200, y: 1130, w: 300, h: 150}, {x: 0, y: 0, w: 1440, h: 1440}, ease.cubicOut);
  const atDepth = 1 - ease.cubicOut(seg(frame, 1194, 1202));
  const neighbours = 1 - ease.cubicOut(seg(cameraAt(frame).zoom, 25, 50));
  return <g transform={`translate(${PAGE.x} ${PAGE.y}) scale(${PAGE_SCALE})`}>
    <rect width="1440" height="1440" fill={PAPER} />
    <g opacity={lod * (1 - block.k) * neighbours} fill={INK}>
      <text x="144" y="188" fontSize="76" fontWeight="500" letterSpacing="12">A GOOD LIFE</text>
      <path d="M144 252H1296" stroke={INK} strokeWidth="5" />
      {['HEALTHY', 'SUCCESSFUL', 'AHEAD'].map((word, i) => <g key={word}>
        <text x="144" y={470 + i * 240} fontSize="133" fontWeight="800" letterSpacing="-3">{word}</text>
        <path d={`M144 ${535 + i * 240}H1296`} stroke={BLUE} strokeOpacity="0.15" strokeWidth="4" />
        <text x="1268" y={467 + i * 240} fontSize="44" textAnchor="end" fill={BLUE}>0{i + 1}</text>
      </g>)}
      <rect x="160" y="1110" width="1120" height="220" fill="none" stroke={BLUE}
        strokeWidth="4" strokeDasharray="14 14" opacity={1 - write} />
    </g>
    {/* This one rectangle survives both dives and grows to be the kept grid cell. */}
    {write > 0 && <rect x={block.x} y={block.y + block.h * (1 - write)} width={block.w}
      height={block.h * write} fill={BLUE} />}
    <g opacity={write * atDepth} fill={PAPER}>
      <text x="350" y="1221" textAnchor="middle" fontSize="45" fontWeight="800"
        letterSpacing="-0.8">YOUR CALL</text>
    </g>
    {/* A deliberate caret stroke, not a new character pose or a screen-space overlay. */}
    <path d="M218 1170V1240" stroke={INK} strokeWidth="8" strokeLinecap="square"
      opacity={ease.cubicOut(seg(frame, 1167, 1171)) * (1 - ease.cubicOut(seg(frame, 1178, 1182)))} />
  </g>;
};
