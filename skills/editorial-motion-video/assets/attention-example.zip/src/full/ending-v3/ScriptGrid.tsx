import {BLUE, INK} from '../OutroMotion';
import {ease, seg} from './OneTakeMotion';
import {cameraMatrix, detailLevel, GRID, matrixText, TARGET} from './ScaleCamera';
import {NestedPage} from './NestedPage';

// The target cell is part of this glyph from the beginning; no new end card.
const QUESTION = [
  '001111100', '011000110', '110000011', '000000011', '000000110',
  '000001100', '000011000', '000011000', '000000000', '000011000', '000011000',
];
const isQuestion = (col: number, row: number) => QUESTION[row - 2]?.[col - 4] === '1';
const cells = Array.from({length: GRID.cols * GRID.rows}, (_, i) => {
  const col = i % GRID.cols, row = Math.floor(i / GRID.cols);
  return {col, row, x: GRID.x + col * GRID.pitch, y: GRID.y + row * GRID.pitch};
});
export const ScriptGrid = ({frame}: {frame: number}) => {
  const dim = ease.cubicOut(seg(frame, 1216, 1230));
  const detail = detailLevel(frame);
  return <g transform={matrixText(cameraMatrix(frame))}>
    <g opacity={(1 - detail) * (1 - dim)} fill={INK}>
      <text x="81" y="173" fontSize="27" fontWeight="700" letterSpacing="5">THE LIFE SCRIPT</text>
      <text x="999" y="174" textAnchor="end" fontSize="19" fontWeight="500">WRITTEN FOR YOU</text>
    </g>
    {cells.map(({col, row, x, y}) => {
      const target = col === TARGET.col && row === TARGET.row;
      const dist = Math.hypot(col - TARGET.col, row - TARGET.row);
      const lit = target ? 0 : isQuestion(col, row)
        ? ease.cubicOut(seg(frame, 1210 + dist * 1.65, 1215 + dist * 1.65)) : 0;
      return <g key={`${col}:${row}`}>
        <rect x={x} y={y} width={GRID.size} height={GRID.size} fill="#E8ECF3"
          opacity={1 - dim * 0.82} />
        {!target && <g opacity={(1 - lit) * (1 - dim * 0.9)} stroke={BLUE} strokeOpacity="0.2" strokeWidth="1.2">
          <path d={`M${x + 7} ${y + 12}h26M${x + 7} ${y + 19}h${16 + (col + row) % 8}M${x + 7} ${y + 26}h22`} />
        </g>}
        {lit > 0 && <rect x={x} y={y} width={GRID.size} height={GRID.size} fill={BLUE} opacity={lit} />}
      </g>;
    })}
    <NestedPage frame={frame} />
  </g>;
};
