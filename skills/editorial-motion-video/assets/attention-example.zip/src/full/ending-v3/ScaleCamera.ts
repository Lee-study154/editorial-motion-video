import {camera, ease, seg, view} from './OneTakeMotion';

export const GRID = {x: 81, y: 230, pitch: 54, size: 46, cols: 17, rows: 17};
export const TARGET = {col: 8, row: 8};
export const PAGE_SCALE = GRID.size / 1440;
export const PAGE = {x: GRID.x + TARGET.col * GRID.pitch, y: GRID.y + TARGET.row * GRID.pitch};
const pagePoint = (x: number, y: number) => ({x: PAGE.x + x * PAGE_SCALE, y: PAGE.y + y * PAGE_SCALE});
const pageCentre = pagePoint(720, 720), gapCentre = pagePoint(350, 1205);
// 1× → 17× → 70×, then 70× → 1×. All times are absolute frames.
const KEYS = [
  {t: 1092, x: 540, y: 768, zoom: 1, rot: 0},
  {t: 1115, x: 540, y: 768, zoom: 1, rot: 0},
  {t: 1149, ...pageCentre, zoom: 17, rot: 0},
  {t: 1152, ...pageCentre, zoom: 17, rot: 0},
  {t: 1176, ...gapCentre, zoom: 70, rot: 0},
  {t: 1194, ...gapCentre, zoom: 70, rot: 0},
  {t: 1225, x: 540, y: 768, zoom: 1, rot: 0, curve: ease.expoInOut},
];
export const cameraAt = (frame: number) => camera(frame, KEYS);
export const cameraMatrix = (frame: number) => view(cameraAt(frame));
export const matrixText = (m: number[]) => `matrix(${m.join(' ')})`;
// LOD is driven by projected cell size, not a separate scene replacement.
export const detailLevel = (frame: number) => ease.cubicOut(seg(GRID.size * cameraAt(frame).zoom, 85, 360));
// Suggested 180-degree shutter times. Root can instead provide its own sampler.
// No post-1233 samples move: the final composition is truly static.
export function motionSampleFrames(frame: number, samples = 7) {
  if (frame < 1093 || frame >= 1233 || (frame >= 1182 && frame <= 1193)) return [frame];
  return Array.from({length: samples}, (_, i) => frame - 0.25 + 0.5 * (i + 0.5) / samples);
}
