import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {BLUE, INK, PAPER} from '../OutroMotion';
import {OutroScenes} from '../OutroScenes';
import {OutroScript} from '../OutroScript';
import {OutroRuler} from '../OutroStandards';
import {ease, lerp, seg} from './OneTakeMotion';
import {ScriptGrid} from './ScriptGrid';

const page = [[337.8, 738.3], [448.2, 780.4], [396.6, 902.7], [305.2, 862.2]];
const screen = [[0, 0], [1080, 0], [1080, 1536], [0, 1536]];
export {cameraAt, motionSampleFrames} from './ScaleCamera';

// Absolute frame prop lets root render genuine fractional shutter samples.
// All new descendants receive this number; none has an integer-time hook.
export const OutroScenesV3 = ({frame: sampleFrame}: {frame?: number} = {}) => {
  const rootFrame = useCurrentFrame(), frame = sampleFrame ?? rootFrame;
  if (frame < 1092) return <OutroScenes />;
  const bridge = ease.expoOut(seg(frame, 1093, 1112));
  const points = page.map((p, i) => `${lerp(p[0], screen[i][0], bridge)},${lerp(p[1], screen[i][1], bridge)}`).join(' ');
  const visible = ease.cubicOut(seg(frame, 1097, 1108));
  const title = ease.cubicOut(seg(frame, 1222, 1233));
  return <AbsoluteFill style={{background: PAPER, overflow: 'hidden', fontFamily: 'Arial, Helvetica, sans-serif'}}>
    <div style={{position: 'absolute', inset: '0 auto auto 0', width: 1080, height: 1536, overflow: 'hidden'}}>
      {frame < 1112 && <>
        <OutroScript frame={1092} />
        <OutroRuler frame={1092} />
      </>}
      <svg width="1080" height="1536" style={{position: 'absolute', inset: 0}}>
        <defs><clipPath id="ending-v3-page-bridge"><polygon points={points} /></clipPath></defs>
        <g clipPath="url(#ending-v3-page-bridge)" opacity={frame <= 1092 ? 0 : seg(frame, 1092, 1094)}>
          <rect width="1080" height="1536" fill={PAPER} />
          <g opacity={visible}><ScriptGrid frame={frame} /></g>
        </g>
        <g opacity={title}>
          <text x="90" y="1286" fill={INK} fontSize="99" fontWeight="800" letterSpacing="-5">WHOSE <tspan fill={BLUE}>SCRIPT?</tspan></text>
          <path d="M95 1323H985" stroke={BLUE} strokeWidth="4" />
        </g>
      </svg>
    </div>
  </AbsoluteFill>;
};
