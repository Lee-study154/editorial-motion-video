// Adapted from onetake/lib/motion.js, lineage otk-7f3e1c.
// © 2026 Patrick (github.com/feitangyuan), PolyForm Noncommercial 1.0.0.
// Public motion primitives only; clearing's composition/score are not public.
export const clamp = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const seg = (t: number, t0: number, t1: number) =>
  t1 === t0 ? (t >= t1 ? 1 : 0) : clamp((t - t0) / (t1 - t0));
const expoIn = (u: number) => u <= 0 ? 0 : u >= 1 ? 1 : (2 ** (10 * u) - 1) / 1023;
export const ease = {
  cubicInOut: (u: number) => u < 0.5 ? 4 * u ** 3 : 1 - (-2 * u + 2) ** 3 / 2,
  cubicOut: (u: number) => 1 - (1 - u) ** 3,
  expoOut: (u: number) => u <= 0 ? 0 : u >= 1 ? 1 : (1 - 2 ** (-10 * u)) / (1 - 2 ** -10),
  expoInOut: (u: number) => u < 0.5 ? expoIn(2 * u) / 2 : 1 - expoIn(2 - 2 * u) / 2,
};
export type Camera = {x: number; y: number; zoom: number; rot: number};
type Key = Camera & {t: number; curve?: (u: number) => number};
// OM.camera: interpolate zoom in log space, not a linear scale tween.
export function camera(t: number, keys: Key[]): Camera {
  if (t <= keys[0].t) return keys[0];
  if (t >= keys[keys.length - 1].t) return keys[keys.length - 1];
  let i = 0;
  while (keys[i + 1].t < t) i++;
  const A = keys[i], B = keys[i + 1];
  const k = (B.curve || ease.cubicInOut)(seg(t, A.t, B.t));
  return {x: lerp(A.x, B.x, k), y: lerp(A.y, B.y, k),
    zoom: Math.exp(lerp(Math.log(A.zoom), Math.log(B.zoom), k)), rot: lerp(A.rot, B.rot, k)};
}
// OM.view: affine screen transform. Focus plane only; no character distortion.
export function view(cam: Camera, W = 1080, H = 1536) {
  const c = Math.cos(cam.rot) * cam.zoom, s = Math.sin(cam.rot) * cam.zoom;
  return [c, s, -s, c, W / 2 - (c * cam.x - s * cam.y), H / 2 - (s * cam.x + c * cam.y)];
}
type Rect = {x: number; y: number; w: number; h: number; r?: number};
// OM.morphRect's non-spring branch; used for the same persistent blue block.
export function morphRect(t: number, t0: number, t1: number, A: Rect, B: Rect,
  curve = ease.expoOut) {
  const k = curve(seg(t, t0, t1));
  const x = lerp(A.x, B.x, k), y = lerp(A.y, B.y, k);
  const w = lerp(A.w, B.w, k), h = lerp(A.h, B.h, k);
  return {k, x, y, w, h, r: lerp(A.r || 0, B.r || 0, k), cx: x + w / 2, cy: y + h / 2};
}
