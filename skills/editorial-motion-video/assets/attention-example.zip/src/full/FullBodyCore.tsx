import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {CodexEnhanced} from '../enhanced/CodexEnhanced';
import {AttentionEnhanced} from '../enhanced/AttentionEnhanced';
import {IdentityEnhanced} from '../enhanced/IdentityEnhanced';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Full-film copy avoids repeating the complete spoken caption in the hero title.
// Cover only the original heading band; retain the accepted core and cue motion.
const FullAttentionHeading = ({frame}: {frame: number}) => <>
  <div style={{position: 'absolute', left: 80, right: 70, top: 210, height: 270,
    background: '#FCFCFB'}} />
  <div style={{position: 'absolute', left: 86, right: 80, top: 224, fontSize: 91,
    lineHeight: 1.04, letterSpacing: -4.6, fontWeight: 800,
    opacity: interpolate(frame, [169, 181], [0, 1], clamp),
    translate: `0px ${interpolate(frame, [169, 187], [24, 0], {
      ...clamp, easing: Easing.bezier(0.22, 1, 0.36, 1)})}px`}}>
    THE ATTENTION<br /><span style={{color: '#002FA7',
      opacity: interpolate(frame, [221, 232], [0, 1], clamp)}}>ECONOMY.</span>
  </div>
</>;

// Mounted at global390: all approved enhanced motions keep their original local frame.
export const FullBodyCore = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{background: '#FCFCFB', overflow: 'hidden'}}>
    {frame >= 155 && frame < 305 && <AttentionEnhanced />}
    {frame >= 169 && frame < 305 && <FullAttentionHeading frame={frame} />}
    {frame < 182 && <CodexEnhanced />}
    {frame >= 295 && <IdentityEnhanced />}
  </AbsoluteFill>;
};
