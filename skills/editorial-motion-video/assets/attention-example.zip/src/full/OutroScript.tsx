import {Img, staticFile} from 'remotion';
import {BLUE, INK, PAPER, lerp, power2Out, tw} from './OutroMotion';

const SCALE = 870 / 1095;
const imageStyle = {position: 'absolute', inset: 0, width: 870, height: 1315 * SCALE} as const;
const part = (name: string) => staticFile(`full/outro-${name}.png`);

// The approved original art is never scaled to simulate character movement.
// Only its complete head and the free page rotate on local, source-space hinges.
export const OutroScript = ({frame}: {frame: number}) => {
  const enter = tw(frame, 1014, 14, power2Out);
  const question = tw(frame, 1092, 15, power2Out);
  const head = 2.6 * tw(frame, 1052, 35) - 2.0 * tw(frame, 1150, 36);
  const leaf = -9 * tw(frame, 1032, 24) + 13 * tw(frame, 1056, 25) - 4 * tw(frame, 1081, 24);
  const near = tw(frame, 1038, 25, power2Out);
  const far = tw(frame, 1078, 25, power2Out);
  const future = tw(frame, 1105, 23, power2Out);
  return <div style={{position: 'absolute', inset: 0, opacity: enter}}>
    <div style={{position: 'absolute', left: 90, top: 226, fontSize: 91, fontWeight: 800,
      lineHeight: 1.02, letterSpacing: -4, color: INK, opacity: 1 - question}}>
      YOUR OWN<br /><span style={{color: BLUE}}>LIFE.</span>
    </div>
    <div style={{position: 'absolute', left: 90, top: 226, fontSize: 91, fontWeight: 800,
      lineHeight: 1.02, letterSpacing: -4, color: INK, opacity: question,
      transform: `translateY(${(1 - question) * 12}px)`}}>
      WHOSE<br /><span style={{color: BLUE}}>SCRIPT?</span>
    </div>
    <div style={{position: 'absolute', left: 105, top: 430, width: 870, height: 1315 * SCALE}}>
      <Img src={part('script-base')} style={imageStyle} />
      <Img src={part('script-leaf')} style={{...imageStyle,
        transformOrigin: `${430 * SCALE}px ${438 * SCALE}px`, transform: `rotate(${leaf}deg)`}} />
      <Img src={part('script-head')} style={{...imageStyle,
        transformOrigin: `${270 * SCALE}px ${275 * SCALE}px`, transform: `rotate(${head}deg)`}} />
      <Img src={part('step-near')} style={{...imageStyle, opacity: near,
        clipPath: `inset(${(1 - near) * 100}% 0 0 0)`}} />
      <Img src={part('step-far')} style={{...imageStyle, opacity: far,
        clipPath: `inset(${(1 - far) * 100}% 0 0 0)`}} />
      {/* This pair stays the original empty dashed outline, including the final hold. */}
      <Img src={part('step-empty')} style={{...imageStyle, opacity: future}} />
    </div>
  </div>;
};

// A paper-shaped match bridge starts at the book's real on-screen page bounds.
export const OutroEnding = ({frame}: {frame: number}) => {
  const open = tw(frame, 1254, 12, power2Out);
  const title = tw(frame, 1262, 10, power2Out);
  const line = tw(frame, 1270, 8, power2Out);
  const source = [[435, 442], [548, 396], [474, 551], [368, 596]];
  const target = [[0, 0], [1080, 0], [1080, 1920], [0, 1920]];
  const points = source.map((p, i) => `${lerp(105 + p[0] * SCALE, target[i][0], open)},${lerp(430 + p[1] * SCALE, target[i][1], open)}`).join(' ');
  return <>
    <svg width="1080" height="1920" style={{position: 'absolute', inset: 0}}>
      <polygon points={points} fill={PAPER} opacity={tw(frame, 1254, 2, power2Out)} />
    </svg>
    <div style={{position: 'absolute', left: 90, top: 590, color: INK,
      fontSize: 137, fontWeight: 800, lineHeight: 1.02, letterSpacing: -7,
      opacity: title, transform: `translateY(${(1 - title) * 16}px)`}}>
      WHOSE<br /><span style={{color: BLUE}}>SCRIPT?</span>
    </div>
    <div style={{position: 'absolute', left: 95, top: 930, height: 4,
      width: 720 * line, background: BLUE}} />
  </>;
};
