import {Img, staticFile} from 'remotion';
import {BLUE, INK, PAPER, buildCurve, clamp01, lerp, power2Out, tw} from './OutroMotion';

const badge = {x: 559.519, y: 795.981, r: 38.5};
const badgeWidth = 123 * 650 / 1030, badgeHeight = 120 * 650 / 1030;
const curves = [230, 850].map(x => buildCurve([
  {x: 540, y: 800}, {x: 540, y: 930}, {x, y: 940}, {x, y: 1090},
]));

// source-converge is deliberately reversed: one stable identity branches out.
// Real 200-segment arc-length sampling and inverse three-stage node sizing are retained.
export const OutroShare = ({frame}: {frame: number}) => {
  const wipe = tw(frame, 803, 12);
  const morph = tw(frame, 815, 7, power2Out);
  const cx = lerp(badge.x, 540, morph), cy = lerp(badge.y, 720, morph);
  const width = lerp(badgeWidth, 430, morph), height = lerp(badgeHeight, 160, morph);
  const iconX = lerp(cx, cx - width / 2 + 69, morph);
  const title = tw(frame, 815, 12, power2Out);
  const maybe = tw(frame, 864, 9, power2Out);
  return <>
    {/* An annular paper wipe preserves the exact approved ME pixels at the center. */}
    {frame < 815 ? <svg width="1080" height="1920" style={{position: 'absolute', inset: 0}}>
      <defs><mask id="outro-badge-paper"><rect width="1080" height="1920" fill="black" />
        <circle cx={badge.x} cy={badge.y} r={1600 * wipe} fill="white" />
        <circle cx={badge.x} cy={badge.y} r={badge.r} fill="black" />
      </mask></defs>
      <rect width="1080" height="1920" fill={PAPER} mask="url(#outro-badge-paper)" />
    </svg> : <div style={{position: 'absolute', inset: 0, background: PAPER}} />}
    <div style={{position: 'absolute', left: 90, top: 226, color: INK, fontSize: 91,
      fontWeight: 800, lineHeight: 1.02, letterSpacing: -4, opacity: title,
      transform: `translateY(${(1 - title) * 18}px)`}}>
      SHARE THE<br /><span style={{color: BLUE}}>IDENTITY.</span>
    </div>
    <svg width="1080" height="1500" style={{position: 'absolute', inset: 0}}>
      {curves.map((c, i) => {
        const draw = tw(frame, 827 + i * 3, 18, power2Out);
        return <path key={`path-${i}`} d={c.d} fill="none" stroke={BLUE} strokeWidth="3"
          strokeDasharray={c.len} strokeDashoffset={c.len * (1 - draw)} opacity="0.6" />;
      })}
      {curves.map((c, i) => {
        const p = tw(frame, 837 + i * 3, 24);
        const point = c.at(c.len * p);
        const reverse = 1 - p;
        const size = Math.max(0, reverse < 0.75 ? lerp(1, 0.34, reverse / 0.75) : lerp(0.34, 0, (reverse - 0.75) / 0.25));
        return <g key={`node-${i}`} transform={`translate(${point.x} ${point.y}) scale(${size})`}>
          <rect x="-134" y="-61" width="268" height="122" rx="25" fill={PAPER} stroke={BLUE} strokeWidth="3" />
          <text textAnchor="middle" y="13" fill={BLUE} fontSize="37" fontWeight="700">SHARED</text>
        </g>;
      })}
      <g opacity={maybe}>
        <path d="M 850 1151 C 850 1230 540 1205 540 1300" fill="none" stroke={BLUE}
          strokeWidth="3" strokeDasharray="9 10" />
        <text x="690" y="1274" textAnchor="middle" fill="#687181" fontSize="23" letterSpacing="3">MAYBE</text>
        <rect x="375" y="1310" width="330" height="105" rx="21" fill={PAPER} stroke={BLUE} strokeWidth="3" strokeDasharray="9 10" />
        <text x="540" y="1378" textAnchor="middle" fill={BLUE} fontSize="50" fontWeight="700">BUY IN?</text>
      </g>
    </svg>
    {frame >= 815 && <>
      <div style={{position: 'absolute', left: cx - width / 2, top: cy - height / 2,
        width, height, boxSizing: 'border-box', border: `3px solid rgba(0,47,167,${morph})`,
        borderRadius: lerp(badge.r, 29, morph), background: PAPER}} />
      <Img src={staticFile('full/outro-me.png')} style={{position: 'absolute',
        width: badgeWidth, height: badgeHeight, left: iconX - badgeWidth / 2, top: cy - badgeHeight / 2}} />
      <div style={{position: 'absolute', left: cx - width / 2 + 134, top: cy - 37,
        color: BLUE, fontSize: 58, fontWeight: 800, letterSpacing: -2,
        opacity: clamp01((morph - 0.25) / 0.75)}}>SHARE</div>
    </>}
  </>;
};
