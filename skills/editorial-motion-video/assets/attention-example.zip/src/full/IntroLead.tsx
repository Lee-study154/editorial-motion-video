import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {IntroBottle} from './IntroBottle';
import {IntroWater} from './IntroWater';
import {IntroRelay} from './IntroRelay';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Mounted directly: all helpers consume the full film's absolute frame.
export const IntroLead = () => {
  const frame = useCurrentFrame();
  if (frame < 144 || frame >= 390) return null;
  return <AbsoluteFill style={{background: '#FCFCFB', color: '#12171E', overflow: 'hidden', fontFamily: 'Arial, Helvetica, sans-serif'}}>
    {frame < 234 ? <IntroBottle frame={frame} /> : frame < 297 ? <IntroWater frame={frame} /> : <>
      <div style={{position: 'absolute', left: 90, top: 108, fontSize: 24, color: '#697383', letterSpacing: 2.5}}>BILIBILI / 薄肌</div>
      <div style={{position: 'absolute', left: 86, top: 224, fontSize: 92, fontWeight: 800, letterSpacing: -4.5, lineHeight: 1.03}}>
        GETTING<br /><span style={{color: '#002FA7'}}>LEAN.</span>
      </div>
      <div style={{position: 'absolute', left: 90, top: 460, width: 900, height: 3, background: '#002FA7'}} />
      <IntroRelay frame={frame} />
      <div style={{position: 'absolute', left: 90, top: 1300, fontSize: 25, color: '#697383'}}>Different advice. A familiar promise.</div>
      {/* The last source remains present at389; this line preserves the left→right reading direction into X. */}
      <div style={{position: 'absolute', left: 90, top: 1400, height: 3, background: '#002FA7',
        width: interpolate(frame, [378, 389], [48, 900], clamp), opacity: interpolate(frame, [375, 382], [0, 1], clamp)}} />
    </>}
  </AbsoluteFill>;
};
