import {Easing, Img, interpolate, staticFile} from 'remotion';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const scale = 1380 / 1045;
// Actual cover bounds in the decoded source, recorded in intro-provenance.json.
const target = {left: 537, top: 216, right: 775, bottom: 395};

export const IntroWater = ({frame}: {frame: number}) => {
  const scan = interpolate(frame, [234, 260], [0, -170], {...clamp, easing: Easing.linear});
  const cx = -330 + (target.left + target.right) / 2 * scale;
  const cy = scan + (target.top + target.bottom) / 2 * scale;
  return <>
    <div style={{position: 'absolute', left: 90, top: 108, fontSize: 24, color: '#697383', letterSpacing: 2.5}}>DOUYIN / 大水理论</div>
    <div style={{position: 'absolute', left: 86, top: 224, fontSize: 90, fontWeight: 800, letterSpacing: -4.5, lineHeight: 1.03}}>
      A HABIT.<br /><span style={{color: '#002FA7'}}>A MOVEMENT.</span>
    </div>
    <div style={{position: 'absolute', left: 90, top: 460, width: 900, height: 3, background: '#002FA7'}} />
    <div style={{position: 'absolute', left: 90, top: 560, width: 900, height: 690, overflow: 'hidden', background: '#191B24'}}>
      <Img src={staticFile('full/intro-douyin.png')} style={{position: 'absolute', left: -330, top: scan, width: 1380, maxWidth: 'none'}} />
      <svg width="900" height="690" style={{position: 'absolute', inset: 0}}>
        <ellipse cx={cx} cy={cy} rx={(target.right - target.left) * scale / 2 + 18}
          ry={(target.bottom - target.top) * scale / 2 + 18} fill="none" stroke="#002FA7" strokeWidth="4"
          pathLength="1" strokeDasharray="1" strokeDashoffset={interpolate(frame, [261, 275], [1, 0], clamp)}
          opacity={interpolate(frame, [260, 263], [0, 1], clamp)} />
      </svg>
    </div>
    <div style={{position: 'absolute', left: 90, top: 1294, color: '#697383', fontSize: 25}}>Real search results · 大水理论</div>
  </>;
};
