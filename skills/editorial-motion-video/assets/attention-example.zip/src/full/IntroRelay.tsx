import {Img, staticFile} from 'remotion';

// Actual still-layout-relay core: CONFIG, tweens, relayState and synchronized ring/dim.
// Source file + SHA recorded in full-film/references/intro-provenance.json.
// Customized: two stations, a flat horizontal ribbon and absolute-film timing.
const CONFIG = {dimB: 0.6, dimScale: 0.985, switchDur: 0.4, ringDur: 0.25, focusScale: 1.03};
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const tw = (t: number, t0: number, d: number, ease: (x: number) => number) => ease(clamp01((t - t0) / d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const power1Out = (x: number) => 1 - Math.pow(1 - x, 2);
const power3Out = (x: number) => 1 - Math.pow(1 - x, 4);
const power2InOut = (x: number) => (x < 0.5 ? 4 * x ** 3 : 1 - Math.pow(-2 * x + 2, 3) / 2);
const COLOR = {base: [110, 110, 115], on: [18, 23, 30], off: [154, 154, 160]};
const lerpRGB = (a: number[], b: number[], p: number) => a.map((v, i) => lerp(v, b[i], p));
const rgb = (c: number[]) => `rgb(${c.map((v) => Math.round(v)).join(',')})`;

export const IntroRelay = ({frame}: {frame: number}) => {
  const t = (frame - 297) / 30;
  const relayState = (j: number) => {
    let b = 1, s = 1, ring = 0, col = COLOR.base;
    const stations: [number, number][] = [[0, 0], [1.4, 1], [2.6, -1]];
    for (const [at, idx] of stations) {
      if (t < at) break;
      const p = tw(t, at, CONFIG.switchDur, power2InOut), pr = tw(t, at, CONFIG.ringDur, power1Out);
      const on = idx === j, resetting = idx < 0;
      b = lerp(b, resetting || on ? 1 : CONFIG.dimB, p);
      s = lerp(s, resetting ? 1 : on ? CONFIG.focusScale : CONFIG.dimScale, p);
      ring = lerp(ring, on ? 1 : 0, pr);
      col = lerpRGB(col, resetting ? COLOR.base : on ? COLOR.on : COLOR.off, p);
    }
    return {b, s, ring, col};
  };
  const drift = -390 * tw(t, 1.2, 0.5, power2InOut);
  return <div style={{position: 'absolute', top: 600, left: 90, width: 1380, height: 650, translate: `${drift}px 0px`}}>
    {['a', 'b'].map((name, i) => {
      // The first station has landed at the cut. The second retains same-direction delayed entry.
      const e = tw(t, i === 0 ? -0.5 : 0, 0.5, power3Out);
      const st = relayState(i);
      return <div key={name} style={{position: 'absolute', left: i * 690, top: 0, width: 600,
        opacity: e, translate: `${lerp(40, 0, e)}px 0px`}}>
        <div style={{position: 'relative', width: 600, height: 507.2,
          scale: String(st.s), filter: `brightness(${st.b})`, transformOrigin: 'center'}}>
          <Img src={staticFile(`full/intro-lean-${name}.png`)} style={{display: 'block', width: 600, height: 507.2, objectFit: 'contain'}} />
          <div style={{position: 'absolute', inset: -6, border: '3px solid #002FA7', borderRadius: 18,
            opacity: st.ring, boxSizing: 'border-box'}} />
        </div>
        <div style={{marginTop: 30, fontSize: 32, fontWeight: 600, color: rgb(st.col), letterSpacing: -0.5}}>
          {i === 0 ? 'HOW TO GET LEAN' : 'THREE STANDARDS'}
        </div>
      </div>;
    })}
  </div>;
};
