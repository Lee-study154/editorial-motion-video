import {useCurrentFrame} from 'remotion';

// Source TTS sentence anchors with disclosed editorial phrase splits.
const captions = [
  {
    "text": "You know what's funny?",
    "startMs": 3300,
    "endMs": 4982,
    "sourceSentence": 1,
    "timing": "TTS sentence"
  },
  {
    "text": "Even drinking water\nneeds a theory now.",
    "startMs": 4982,
    "endMs": 7794,
    "sourceSentence": 2,
    "timing": "TTS sentence"
  },
  {
    "text": "On Douyin,\nChina's TikTok,",
    "startMs": 7794,
    "endMs": 9750,
    "sourceSentence": 3,
    "timing": "editorial phrase"
  },
  {
    "text": "big water bottles\nand getting lean",
    "startMs": 9750,
    "endMs": 11650,
    "sourceSentence": 3,
    "timing": "editorial phrase"
  },
  {
    "text": "are whole\nlifestyle movements.",
    "startMs": 11650,
    "endMs": 13350,
    "sourceSentence": 3,
    "timing": "editorial phrase"
  },
  {
    "text": "Then you open X,\nand it's Codex.",
    "startMs": 13350,
    "endMs": 15966,
    "sourceSentence": 4,
    "timing": "TTS sentence"
  },
  {
    "text": "Somehow, you're\nalready behind.",
    "startMs": 15966,
    "endMs": 18639,
    "sourceSentence": 5,
    "timing": "TTS sentence"
  },
  {
    "text": "Different topics.",
    "startMs": 18639,
    "endMs": 20399,
    "sourceSentence": 6,
    "timing": "TTS sentence"
  },
  {
    "text": "Same business:\nyour attention.",
    "startMs": 20399,
    "endMs": 22829,
    "sourceSentence": 7,
    "timing": "TTS sentence"
  },
  {
    "text": "Give a habit a name.",
    "startMs": 22829,
    "endMs": 24693,
    "sourceSentence": 8,
    "timing": "TTS sentence"
  },
  {
    "text": "Make it part of\nwho you are.",
    "startMs": 24693,
    "endMs": 26753,
    "sourceSentence": 9,
    "timing": "TTS sentence"
  },
  {
    "text": "Now people share it\u2014",
    "startMs": 26753,
    "endMs": 28450,
    "sourceSentence": 10,
    "timing": "editorial phrase"
  },
  {
    "text": "and maybe buy into it.",
    "startMs": 28450,
    "endMs": 29959,
    "sourceSentence": 10,
    "timing": "editorial phrase"
  },
  {
    "text": "But if your feed\nkeeps defining",
    "startMs": 29959,
    "endMs": 31700,
    "sourceSentence": 11,
    "timing": "editorial phrase"
  },
  {
    "text": "what healthy, successful,\nand ahead look like,",
    "startMs": 31700,
    "endMs": 33800,
    "sourceSentence": 11,
    "timing": "editorial phrase"
  },
  {
    "text": "whose standards\nare you living by?",
    "startMs": 33800,
    "endMs": 36382,
    "sourceSentence": 11,
    "timing": "editorial phrase"
  },
  {
    "text": "Are you solving\nyour own problems\u2014",
    "startMs": 36382,
    "endMs": 38200,
    "sourceSentence": 12,
    "timing": "editorial phrase"
  },
  {
    "text": "or following\nsomeone else's script",
    "startMs": 38200,
    "endMs": 39800,
    "sourceSentence": 12,
    "timing": "editorial phrase"
  },
  {
    "text": "for what your life\nshould look like?",
    "startMs": 39800,
    "endMs": 41730,
    "sourceSentence": 12,
    "timing": "editorial phrase"
  }
];

export const FullCaptions = () => {
  const frame = useCurrentFrame();
  const ms = frame / 30 * 1000;
  const caption = captions.find(c => ms >= c.startMs && ms < c.endMs);
  if (!caption) return null;
  return <div style={{position: 'absolute', left: 90, right: 90, top: 1568, zIndex: 50,
    color: '#12171E', fontFamily: 'Arial, Helvetica, sans-serif', fontSize: 52,
    lineHeight: 1.18, letterSpacing: -1.1, fontWeight: 500, whiteSpace: 'pre-line'}}>
    <div style={{width: 48, height: 5, background: '#002FA7', marginBottom: 25}} />
    {caption.text}
  </div>;
};
