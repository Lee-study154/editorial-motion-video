import {useLayoutEffect, useRef, useState} from 'react';
import {continueRender, delayRender} from 'remotion';
import {BLUE, INK, backOut, clamp01, lerp, power1Out, power2In, power2InOut, power2Out, power3Out, tw} from './OutroMotion';

// Actual TalkCraft word-slot-cycle adaptation. The reel/width/blur/ghost/fly/final
// mechanics below retain the original algorithm; only copy, geometry and timing change.
const words = ['HEALTHY', 'SUCCESSFUL'];
const CONFIG = {row: 108, pad: 64, swap: 8, swapBlur: 4, ghostAlpha: 0.13};
export const OutroStandards = ({frame}: {frame: number}) => {
  const f = frame - 900;
  const measRef = useRef<HTMLSpanElement>(null);
  const [m, setM] = useState<{ws: number[]; finW: number} | null>(null);
  const [handle] = useState(() => delayRender('outro word-slot-cycle: measure actual Arial widths'));
  const continued = useRef(false);
  useLayoutEffect(() => {
    const el = measRef.current;
    const q = (k: string) => el?.querySelector<HTMLSpanElement>(`span[data-k="${k}"]`)?.offsetWidth ?? 0;
    setM({ws: words.map((_, i) => q(`w${i}`) + CONFIG.pad), finW: q('fin')});
    if (!continued.current) {continueRender(handle); continued.current = true;}
  }, [handle]);
  const ws = m?.ws ?? [410, 600], finW = m?.finW ?? 330;
  const swapAt = (i: number) => 66 + (i - 1) * 21;
  const lastAt = 87;
  const stemIn = tw(f, 0, 12, power3Out), pillIn = tw(f, 39, 12, power3Out);
  const exitK = 1 - tw(frame, 1005, 9, power2In);
  let idx = 0, width = ws[0], blur = 0, curIdx = 0;
  for (let i = 1; i < words.length; i++) {
    const at = swapAt(i), p = clamp01((f - at) / CONFIG.swap);
    idx += power2InOut(p);
    if (f >= at) width = lerp(ws[i - 1], ws[i], power2InOut(p));
    if (f >= at && f < at + CONFIG.swap) blur = p < 0.45
      ? CONFIG.swapBlur * (p / 0.45) ** 2
      : CONFIG.swapBlur * (1 - power2Out((p - 0.45) / 0.55));
    if (f >= at + CONFIG.swap) curIdx = i;
  }
  let gk = tw(f, 48, 9, power1Out);
  for (let i = 1; i < words.length; i++) {
    const at = swapAt(i);
    if (f >= at && f < at + 3) gk = 1 - power1Out((f - at) / 3);
    else if (f >= at + 3 && f < at + CONFIG.swap) gk = 0;
    else if (f >= at + CONFIG.swap && f < at + CONFIG.swap + 4.5) gk = power1Out((f - at - CONFIG.swap) / 4.5);
  }
  if (f >= lastAt - 3.6) gk = Math.min(gk, 1 - power1Out(clamp01((f - (lastAt - 3.6)) / 3.6)));
  const ghostA = gk * CONFIG.ghostAlpha;
  const fly = tw(f, lastAt, 7, power2In);
  const slotW = f >= lastAt ? lerp(ws[words.length - 1], finW, tw(f, lastAt, 9, power2Out)) : width;
  const finRaw = clamp01((f - 91) / 14), finP = backOut(1.4)(finRaw);
  const ghost = {position: 'absolute', left: 32, height: CONFIG.row, lineHeight: `${CONFIG.row}px`,
    fontSize: 70, fontWeight: 700, whiteSpace: 'nowrap', opacity: ghostA} as const;
  return <div style={{position: 'absolute', inset: 0, color: INK}}>
    <div style={{position: 'absolute', left: 90, top: 226, fontSize: 91,
      fontWeight: 800, lineHeight: 1.02, letterSpacing: -4, opacity: stemIn * exitK}}>
      WHO SETS<br /><span style={{color: BLUE}}>THE STANDARD?</span>
    </div>
    {/* Fixed stem and left anchor: a changing capsule never reflows the sentence. */}
    <div style={{position: 'absolute', left: 90, top: 680, fontSize: 38,
      fontWeight: 700, letterSpacing: 1.5, opacity: stemIn * exitK,
      transform: `translateY(${lerp(14, 0, stemIn)}px)`}}>WHAT COUNTS AS</div>
    <div style={{position: 'absolute', left: 90, top: 835, height: CONFIG.row, width: slotW}}>
      <span style={{...ghost, top: -102}}>{words[curIdx - 1] ?? ''}</span>
      <span style={{position: 'absolute', left: 0, top: 0, width, height: CONFIG.row,
        borderRadius: 999, background: INK, color: '#fff', overflow: 'hidden',
        opacity: pillIn * (1 - fly), transform: `translateY(${lerp(14, 0, pillIn) - 175 * fly}px)`,
        filter: `blur(${10 * fly}px)`}}>
        <span style={{position: 'absolute', left: 0, top: 0, display: 'flex', flexDirection: 'column',
          transform: `translateY(${-idx * CONFIG.row}px)`, filter: `blur(${blur}px)`}}>
          {words.map(w => <span key={w} style={{height: CONFIG.row, lineHeight: `${CONFIG.row}px`,
            padding: '0 32px', fontSize: 70, fontWeight: 700, whiteSpace: 'nowrap'}}>{w}</span>)}
        </span>
      </span>
      <span style={{...ghost, top: 116}}>{words[curIdx + 1] ?? ''}</span>
      <span style={{position: 'absolute', left: 0, top: 0, height: CONFIG.row,
        lineHeight: `${CONFIG.row}px`, fontSize: 100, fontWeight: 800, letterSpacing: -3,
        whiteSpace: 'nowrap', color: BLUE, opacity: Math.min(1, finRaw * 3),
        transform: `translateY(${lerp(130, 0, finP)}px)`}}>AHEAD</span>
    </div>
    <span ref={measRef} style={{position: 'absolute', visibility: 'hidden', whiteSpace: 'nowrap', fontWeight: 700}}>
      {words.map((w, i) => <span key={w} data-k={`w${i}`} style={{display: 'inline-block', fontSize: 70}}>{w}</span>)}
      <span data-k="fin" style={{display: 'inline-block', fontSize: 100, fontWeight: 800, letterSpacing: -3}}>AHEAD</span>
    </span>
  </div>;
};

// One continuous scale becomes the illustrated route across the 1014 boundary.
export const OutroRuler = ({frame}: {frame: number}) => {
  const morph = tw(frame, 1014, 28);
  const end = [{x: 410, y: 1400}, {x: 560, y: 1250}, {x: 680, y: 1100}, {x: 784, y: 976}, {x: 870, y: 865}];
  const points = end.map((p, i) => ({x: lerp(90 + i * 225, p.x, morph), y: lerp(1190, p.y, morph)}));
  const pointer = frame < 987 ? lerp(225, 575, tw(frame, 966, 8)) : lerp(575, 895, tw(frame, 991, 14));
  const lineOpacity = lerp(0.65, 0.19, morph) * (1 - tw(frame, 1120, 35));
  return <svg width="1080" height="1500" style={{position: 'absolute', inset: 0}}>
    <polyline points={points.map(p => `${p.x},${p.y}`).join(' ')} fill="none" stroke={BLUE}
      strokeWidth={lerp(3, 2, morph)} opacity={lineOpacity} />
    {Array.from({length: 13}, (_, i) => <line key={i} x1={90 + i * 75} x2={90 + i * 75}
      y1={1178} y2={i % 3 === 0 ? 1220 : 1205} stroke={INK} strokeWidth="2"
      opacity={(1 - morph) * 0.3} />)}
    <path d={`M ${pointer - 12} 1150 L ${pointer + 12} 1150 L ${pointer} 1172 Z`}
      fill={BLUE} opacity={1 - morph} />
  </svg>;
};
