import {interpolate} from 'remotion';
import {Bottle} from '../Bottle';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const blue = '#002FA7';

export const IntroBottle = ({frame}: {frame: number}) => {
  const motion = interpolate(frame, [144, 158, 216, 234], [0, 1, 1, 0], clamp);
  const wave = Math.sin((frame - 144) / 30 * Math.PI * 1.1) * 3 * motion;
  const rule = interpolate(frame, [219, 234], [0, 900], clamp);
  return <>
    {/* Directly continue the original at the absolute frame; no repeated contour reveal. */}
    <Bottle />
    <svg viewBox="0 0 1080 1160" style={{position: 'absolute', left: 0, top: 350, width: 1080, height: 1160}}>
      <defs><clipPath id="full-intro-water-interior"><path d="M434 179 H646 V245 Q646 290 706 340 V1000 Q706 1041 665 1041 H415 Q374 1041 374 1000 V340 Q434 290 434 245 Z" /></clipPath></defs>
      <g clipPath="url(#full-intro-water-interior)" opacity={motion}>
        <rect x="374" y="688" width="332" height="90" fill="#FCFCFB" />
        <path d={`M365 ${720 + wave} Q460 ${690 - wave} 550 ${720 + wave} T720 ${720 + wave} V1050 H365 Z`} fill="#E3EBFF" />
        <path d={`M365 ${720 + wave} Q460 ${690 - wave} 550 ${720 + wave} T720 ${720 + wave}`} fill="none" stroke={blue} strokeWidth="3" />
      </g>
      <g transform="translate(620 410) rotate(10)" opacity={interpolate(frame, [165, 180, 213, 226], [0, 1, 1, 0], clamp)}>
        <path d="M145 34 H315" fill="none" stroke={blue} strokeWidth="2.5" pathLength="1"
          strokeDasharray="1" strokeDashoffset={interpolate(frame, [165, 180], [1, 0], clamp)} />
      </g>
    </svg>
    <div style={{position: 'absolute', left: 86, top: 185, fontSize: 82, fontWeight: 800,
      lineHeight: 1.05, letterSpacing: -3.8, opacity: interpolate(frame, [153, 168], [0, 1], clamp)}}>
      EVERY HABIT.<br /><span style={{color: blue}}>A THEORY?</span>
    </div>
    <div style={{position: 'absolute', left: 90, top: 460, width: rule, height: 3, background: blue}} />
  </>;
};
