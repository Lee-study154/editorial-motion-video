import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {PAPER} from './OutroMotion';
import {OutroShare} from './OutroShare';
import {OutroRuler, OutroStandards} from './OutroStandards';
import {OutroEnding, OutroScript} from './OutroScript';

// Mount directly at root: every checkpoint uses global absolute 30fps frames.
export const OutroScenes = () => {
  const frame = useCurrentFrame();
  if (frame < 803) return null;
  return <AbsoluteFill style={{fontFamily: 'Arial, Helvetica, sans-serif', overflow: 'hidden',
    background: frame >= 900 ? PAPER : undefined}}>
    {frame < 900 && <OutroShare frame={frame} />}
    {frame >= 900 && frame < 1014 && <OutroStandards frame={frame} />}
    {frame >= 1014 && <OutroScript frame={Math.min(frame, 1254)} />}
    {frame >= 900 && frame < 1155 && <OutroRuler frame={frame} />}
    {frame >= 1254 && <OutroEnding frame={frame} />}
  </AbsoluteFill>;
};
