import {Freeze, useCurrentFrame} from 'remotion';
import {FullFilmV3} from './FullFilmV3';

// Layout stays in 1080×1920 design coordinates; rendering at scale 2 redraws
// text, SVG and CSS at 2160×3840. Half frames are evaluated, never duplicated.
export const FullFilmMaster = ({shutterOffset = 0}: {shutterOffset?: number}) => {
  const outputFrame = useCurrentFrame();
  const designFrame = Math.min(1295, outputFrame / 2);
  return <Freeze frame={designFrame}>
    <FullFilmV3 shutterOffset={shutterOffset} />
  </Freeze>;
};
