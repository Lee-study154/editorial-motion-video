import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame} from 'remotion';
import {Bottle} from './Bottle';
import {WindowCard, type WindowSpec} from './WindowCard';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const blue = '#002FA7';
const windows: WindowSpec[] = [
  {
    id: 'bilibili', title: 'bilibili / 薄肌', src: 'screens/bilibili.jpg',
    imageWidth: 825, imageHeight: 235, x: 105, y: 210, width: 810,
    rotation: -5, tilt: 5, start: 0, exitX: -1130, exitY: -120,
  },
  {
    id: 'alan', title: 'X / @AlanShao111', src: 'screens/alan.png',
    imageWidth: 1179, imageHeight: 668, x: 205, y: 390, width: 760,
    rotation: 5, tilt: -6, start: 6, exitX: 1150, exitY: -160,
  },
  {
    id: 'douyin', title: 'douyin / 大水理论', src: 'screens/douyin.jpg',
    imageWidth: 1045, imageHeight: 650, x: 85, y: 715, width: 830,
    rotation: -5, tilt: 5, start: 12, exitX: -1180, exitY: 100,
  },
  {
    id: 'justin-sun', title: 'X / @justinsuntron', src: 'screens/justin-sun.png',
    imageWidth: 1179, imageHeight: 816, x: 225, y: 995, width: 760,
    rotation: 4, tilt: -5, start: 18, exitX: 1160, exitY: 140,
  },
  {
    id: 'x-codex', title: 'X / @OpenAI / Codex', src: 'screens/x-codex.jpg',
    imageWidth: 598, imageHeight: 766, x: 90, y: 925, width: 440,
    rotation: -6, tilt: 5, start: 24, exitX: -1000, exitY: 150,
  },
  {
    id: 'katherine', title: 'X / @Katherine1198', src: 'screens/katherine.png',
    imageWidth: 1179, imageHeight: 1102, x: 112, y: 620, width: 860,
    rotation: -2.5, tilt: -2, start: 30, exitX: 0, exitY: 0,
  },
];

// 1080×1920 / 30 fps / 144 frames. No audio: this is the motion proof.
export const Opening = () => {
  const frame = useCurrentFrame();
  // This tree receives fractional time in the original 30-fps design clock.
  const fps = 30;
  const focus = Math.min(1, spring({
    frame: frame - 54, fps, durationInFrames: 18,
    config: {damping: 24, stiffness: 150, mass: 0.8},
  }));
  const wipe = interpolate(frame, [77, 96], [0, 1], {
    ...clamp, easing: Easing.bezier(0.65, 0, 0.35, 1),
  });
  const labelLift = interpolate(frame, [77, 91], [0, 1], {
    ...clamp, easing: Easing.bezier(0.45, 0, 0.25, 1),
  });
  const labelOut = interpolate(frame, [91, 96], [0, 1], {
    ...clamp, easing: Easing.in(Easing.cubic),
  });
  const labelY = interpolate(labelLift, [0, 1], [1445, 650]);
  const ruleLength = interpolate(frame, [72, 92], [0, 935], {
    ...clamp, easing: Easing.bezier(0.2, 0.65, 0.2, 1),
  });

  return (
    <AbsoluteFill style={{
      overflow: 'hidden', color: '#12171E', backgroundColor: '#FCFCFB',
      fontFamily: 'Arial, "PingFang SC", "Microsoft YaHei", sans-serif',
    }}>
      <AbsoluteFill style={{
        background: 'radial-gradient(ellipse at 50% 48%, #FFFFFF 0%, #F1F3F7 100%)',
        opacity: interpolate(frame, [77, 96], [1, 0], clamp),
      }} />

      {/* 0–54: individual pop-ins; 54–72: five side/back exits, hero squares up. */}
      <AbsoluteFill style={{
        perspective: 1800, perspectiveOrigin: '50% 48%',
        opacity: interpolate(frame, [83, 90], [1, 0], clamp),
      }}>
        {windows.map((spec, index) => (
          <WindowCard key={spec.id} spec={spec} index={index} focus={focus} />
        ))}
      </AbsoluteFill>

      {/* Leader begins at 水, after the hero is almost square and stationary. */}
      {frame >= 68 && frame < 98 && <svg viewBox="0 0 1080 1920" style={{
        position: 'absolute', inset: 0, width: 1080, height: 1920,
        opacity: interpolate(frame, [77, 88], [1, 0], clamp),
        pointerEvents: 'none',
      }}>
        <path d="M134 876 V1380 Q134 1410 164 1410 H405" fill="none"
          stroke={blue} strokeWidth="3" pathLength="1" strokeDasharray="1"
          strokeDashoffset={interpolate(frame, [68, 77], [1, 0], clamp)} />
        <circle cx="134" cy="876" r="5" fill={blue}
          opacity={interpolate(frame, [68, 70], [0, 1], clamp)} />
      </svg>}

      {/* 72–96: the external keyword owns the transition; paper clears the feed. */}
      <div style={{
        position: 'absolute', inset: '0 auto 0 0', width: 1080 * wipe,
        background: '#FCFCFB',
        boxShadow: wipe > 0 && wipe < 1 ? '25px 0 55px 25px #FCFCFB' : 'none',
      }} />
      {frame >= 70 && frame < 99 && <>
        <div style={{
          position: 'absolute', left: interpolate(labelLift, [0, 1], [110, 86]),
          top: labelY,
          translate: `0px ${interpolate(frame, [70, 75], [14, 0], clamp) - 20 * labelOut}px`,
          opacity: interpolate(frame, [70, 74], [0, 1], clamp) * (1 - labelOut),
          fontSize: interpolate(labelLift, [0, 1], [70, 92]),
          lineHeight: 1.1, letterSpacing: -2.5, fontWeight: 700,
          color: blue, whiteSpace: 'nowrap', background: '#FCFCFB',
          padding: '12px 20px', marginLeft: -20, marginTop: -12,
        }}>
          <span style={{fontSize: '0.66em', letterSpacing: -1, marginRight: 16}}>大水 /</span>
          BIG WATER
        </div>
        <div style={{
          position: 'absolute', left: 86, top: labelY + 110,
          width: ruleLength, height: 6, backgroundColor: blue,
          opacity: 1 - labelOut,
          transformOrigin: 'right center',
          scale: `${1 - labelOut} 1`,
        }}>
          <div style={{
            position: 'absolute', right: -7, top: -6, width: 18, height: 18,
            borderRadius: '50%', background: blue,
          }} />
        </div>
      </>}

      {/* 91–144: overlap the wipe with a fast contour reveal, then hold. */}
      <Bottle />
    </AbsoluteFill>
  );
};
