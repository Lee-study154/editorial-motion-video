import {interpolate, useCurrentFrame} from 'remotion';

// Adapted from video-talkcraft/template/cards/source-converge.tsx (actual copied core).
// Upstream SHA256: a00163db942ec12861a243ad46e6b980804e8dd245cdcf5359b9bf06c5260673
// Preserved: 200-segment arc-length lookup, .75 shrink knee, two packet cycles + .13 phases,
// swallow pulse, source-first erase, centered result hold. Retimed for a 126-frame portrait shot.
const BLUE = '#002FA7';
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const tw = (t: number, t0: number, d: number, ease: (x: number) => number) => ease(clamp01((t - t0) / d));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const linear = (x: number) => x;
const power1Out = (x: number) => 1 - Math.pow(1 - x, 2);
const power2Out = (x: number) => 1 - Math.pow(1 - x, 3);
const power3Out = (x: number) => 1 - Math.pow(1 - x, 4);
const power2InOut = (x: number) => (x < 0.5 ? 4 * x ** 3 : 1 - Math.pow(-2 * x + 2, 3) / 2);
const backOut = (s = 1.70158) => (x: number) => {const u = x - 1; return 1 + (s + 1) * u * u * u + s * u * u;};
type Pt = {x: number; y: number};
type Curve = {d: string; len: number; at: (length: number) => Pt};
const cubic = (p0: number, p1: number, p2: number, p3: number, u: number) => {
  const v = 1 - u;
  return v * v * v * p0 + 3 * v * v * u * p1 + 3 * v * u * u * p2 + u * u * u * p3;
};
function buildCurve(P: [Pt, Pt, Pt, Pt], N = 200): Curve {
  const pts: Pt[] = [], cum: number[] = [0];
  for (let k = 0; k <= N; k++) {
    const u = k / N;
    pts.push({x: cubic(P[0].x, P[1].x, P[2].x, P[3].x, u), y: cubic(P[0].y, P[1].y, P[2].y, P[3].y, u)});
    if (k) cum.push(cum[k - 1] + Math.hypot(pts[k].x - pts[k - 1].x, pts[k].y - pts[k - 1].y));
  }
  const len = cum[N];
  const at = (length: number): Pt => {
    const q = Math.max(0, Math.min(len, length));
    let lo = 0, hi = N;
    while (hi - lo > 1) {const mid = (lo + hi) >> 1; if (cum[mid] <= q) lo = mid; else hi = mid;}
    const seg = cum[hi] - cum[lo] || 1, f = (q - cum[lo]) / seg;
    return {x: lerp(pts[lo].x, pts[hi].x, f), y: lerp(pts[lo].y, pts[hi].y, f)};
  };
  return {d: `M ${P[0].x},${P[0].y} C ${P[1].x},${P[1].y} ${P[2].x},${P[2].y} ${P[3].x},${P[3].y}`, len, at};
}
const curves = [690, 920, 1150].map((y) => buildCurve([
  {x: 230, y}, {x: 440, y}, {x: 560, y: 920}, {x: 760, y: 920},
]));
const labels = ['WATER', 'LEAN', 'CODEX'];

export const BodySourceConverge = () => {
  const frame = useCurrentFrame();
  const conv = tw(frame, 199, 38, power2InOut);
  const pk = tw(frame, 181, 59, linear);
  const pkOn = tw(frame, 181, 7, power1Out) - tw(frame, 234, 6, power1Out);
  const erase = tw(frame, 240, 10, power2Out);
  const size = Math.max(0, conv < 0.75 ? lerp(1, 0.34, conv / 0.75) : lerp(0.34, 0, (conv - 0.75) / 0.25));
  const hubIn = tw(frame, 182, 12, power3Out);
  let hs = lerp(0.7, 1, hubIn);
  if (frame >= 233) hs = frame < 241 ? lerp(1, 1.12, tw(frame, 233, 8, backOut(2))) : lerp(1.12, 1, tw(frame, 241, 8, power2Out));
  const cx = lerp(760, 540, tw(frame, 249, 10, power2InOut));
  return <svg viewBox="0 0 1080 1920" style={{position: 'absolute', inset: 0, width: 1080, height: 1920}}>
    {curves.map((c, i) => {
      const draw = tw(frame, 173 + i * 4, 17, power2Out);
      return <path key={`path-${i}`} d={c.d} fill="none" stroke="#A6B9E1" strokeWidth="3"
        strokeDasharray={c.len} strokeDashoffset={c.len * (1 - draw) - erase * c.len} />;
    })}
    {curves.map((c, i) => {
      const cyc = (pk * 2 + i * 0.13) % 1;
      const p = c.at(cyc * c.len);
      return <circle key={`packet-${i}`} r="7" cx={p.x} cy={p.y} fill={BLUE}
        opacity={pkOn * (1 - Math.abs(cyc - 0.5) * 0.6)} />;
    })}
    {curves.map((c, i) => {
      const p = c.at(conv * c.len);
      const nodeIn = tw(frame, i === 2 ? 171 : 169 + i * 4, 10, power1Out);
      return <g key={labels[i]} transform={`translate(${p.x} ${p.y}) scale(${size})`} opacity={nodeIn}>
        <rect x="-140" y="-54" width="280" height="108" rx="54" fill="#FCFCFB" stroke="#C5CFDF" strokeWidth="2" />
        <text y="13" textAnchor="middle" fontSize="37" fontWeight="700" fill="#12171E">{labels[i]}</text>
      </g>;
    })}
    {frame < 295 && <g transform={`translate(${cx} 920) scale(${hs})`} opacity={hubIn}>
      <circle r="192" fill="none" stroke={BLUE} strokeWidth="2" opacity=".12" />
      <circle r="170" fill={BLUE} />
      <text y="13" textAnchor="middle" fill="white" fontSize="39" fontWeight="700" letterSpacing="-1">ATTENTION</text>
    </g>}
    <text x={cx} y="1190" textAnchor="middle" fill={BLUE} fontSize="23" letterSpacing="2.7"
      opacity={interpolate(frame, [250, 259], [0, 0.7], clamp)}>THE INCENTIVE STAYS.</text>
  </svg>;
};
