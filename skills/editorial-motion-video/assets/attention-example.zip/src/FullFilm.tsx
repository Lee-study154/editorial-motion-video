import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {Opening} from './Opening';
import {IntroLead} from './full/IntroLead';
import {FullBodyCore} from './full/FullBodyCore';
import {FullCaptions} from './full/FullCaptions';
import {OutroScenes} from './full/OutroScenes';

export const FullFilm = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{background: '#FCFCFB', color: '#12171E', overflow: 'hidden',
    fontFamily: 'Arial, Helvetica, sans-serif'}}>
    {frame < 144 && <Opening />}
    {frame >= 144 && frame < 390 && <IntroLead />}
    {frame >= 390 && frame < 830 && <Sequence from={390} durationInFrames={440}>
      <FullBodyCore />
    </Sequence>}
    {frame >= 803 && <OutroScenes />}
    <FullCaptions />
  </AbsoluteFill>;
};
