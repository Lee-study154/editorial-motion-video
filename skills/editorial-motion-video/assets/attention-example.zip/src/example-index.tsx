import {Composition,registerRoot} from 'remotion';
import {FullFilmMaster} from './FullFilmMaster';
import {FullFilmV3} from './FullFilmV3';
const Root=()=> <>
  <Composition id="AttentionMaster4K60" component={FullFilmMaster} width={1080} height={1920} fps={60} durationInFrames={2592} defaultProps={{shutterOffset:0}}/>
  <Composition id="AttentionFullFilmV3" component={FullFilmV3} width={1080} height={1920} fps={30} durationInFrames={1296} defaultProps={{shutterOffset:0}}/>
</>;
registerRoot(Root);
