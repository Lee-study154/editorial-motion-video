import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {existsSync} from 'node:fs';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {bundle} from '@remotion/bundler';
import {openBrowser, renderMedia, renderStill, selectComposition} from '@remotion/renderer';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const out = path.join(root, 'legacy/full-film/master-4k60');
const python = process.env.PYTHON_EXECUTABLE || 'python3';
const bundledEncoder = path.join(root, `node_modules/@remotion/compositor-${process.platform}-${process.arch}/ffmpeg`);
const encoder = process.env.FFMPEG_EXECUTABLE || (existsSync(bundledEncoder) ? bundledEncoder : 'ffmpeg');
const chromePath = process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
if (!existsSync(chromePath)) throw new Error('Set CHROME_PATH to an installed Chrome; no download was attempted.');
const args = process.argv.slice(2);
const hash = data => createHash('sha256').update(data).digest('hex');
const run = async (command, argv) => {
  const child = spawn(command, argv, {stdio: 'inherit'});
  const [code] = await once(child, 'close');
  if (code !== 0) throw new Error(`${command} exited ${code}`);
};
await mkdir(path.join(out, 'reports'), {recursive: true});
await mkdir(path.join(out, 'work'), {recursive: true});

async function assemble() {
  const work = path.join(out, 'work');
  await writeFile(path.join(work, 'concat.txt'), "file 'prefix.mp4'\nfile 'ending.mp4'\n");
  await run('ffmpeg', ['-v','warning','-y','-f','concat','-safe','0','-i',path.join(work,'concat.txt'),
    '-i',path.resolve(out,'../ending-v3/audio/mix.m4a'),'-map','0:v:0','-map','1:a:0',
    '-c','copy','-t','43.2','-movflags','+faststart',path.join(out,'attention-economy-4k60.mp4')]);
  await run('ffmpeg', ['-v','warning','-y','-i',path.join(out,'attention-economy-4k60.mp4'),
    '-vf','scale=1080:1920:flags=lanczos','-c:v','libx264','-crf','20','-preset','medium',
    '-threads','4','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',
    path.join(out,'attention-economy-preview.mp4')]);
}
if (args.includes('--assemble')) {await assemble(); process.exit(0);}

const serveUrl = await bundle({entryPoint:path.join(root,'src/example-index.tsx'),
  publicDir:path.join(root,'public'),outDir:path.join(out,'work/bundle')});
const browser = await openBrowser('chrome', {
  browserExecutable:chromePath,
});
try {
  const composition = await selectComposition({serveUrl,id:'AttentionMaster4K60',puppeteerInstance:browser});
  if (composition.fps !== 60 || composition.durationInFrames !== 2592) throw new Error('Invalid master clock');
  const shot = async (frame, offset = 0, scale = 2, config = composition) => {
    const props = {...config.props,shutterOffset:offset};
    return renderStill({composition:{...config,props},serveUrl,puppeteerInstance:browser,
      frame,scale,inputProps:props,imageFormat:'png',logLevel:'error'});
  };
  if (args.includes('--probe')) {
    const source = await selectComposition({serveUrl,id:'AttentionFullFilmV3',puppeteerInstance:browser});
    const matching = [], moving = [];
    for (const frame of [60,96,120,234,390,465,559,685,900,1092,1176,1233]) {
      const a = await shot(frame,0,1,source), b = await shot(frame*2,0,1);
      const equal = hash(a.buffer) === hash(b.buffer);
      matching.push({designFrame:frame,masterFrame:frame*2,equal});
      if (!equal) throw new Error(`Master changed source at design frame ${frame}`);
    }
    for (const frame of [40,120,468,820,1140,1390,2070,2250,2406]) {
      const a = await shot(frame), b = await shot(frame+1);
      const distinct = hash(a.buffer) !== hash(b.buffer);
      moving.push({frame,distinct});
      if (!distinct) throw new Error(`Expected fractional motion at output frame ${frame}`);
    }
    const exposures = [];
    for (const offset of [-.1,.1]) exposures.push(hash((await shot(2406,offset)).buffer));
    if (exposures[0] === exposures[1]) throw new Error('Shutter offset did not affect pixels');
    await writeFile(path.join(out,'reports/clock-probe.json'),JSON.stringify({status:'PASS',
      matching,moving,shutter:{frame:2406,offsets:[-.1,.1],hashes:exposures},
      sourceFPS:30,outputFPS:60,scale:2,dimensions:[2160,3840]},null,2));
    console.log('PASS: 12 exact source-time matches; 9 distinct half-frame pairs; shutter props effective.');
  } else if (args.includes('--ending') || args.includes('--ending-benchmark')) {
    const range = args.includes('--ending-benchmark') ? [2400,2411] : [2184,2591];
    const filename = args.includes('--ending-benchmark') ? 'benchmark-ending.mp4' : 'ending.mp4';
    const merger = spawn(python,[path.resolve(out,'../ending-v3/shutter_merge.py')],{stdio:['pipe','pipe','inherit']});
    const ffmpeg = spawn(encoder,['-v','warning','-y','-f','image2pipe','-framerate','60',
      '-c:v','png','-i','pipe:0','-an','-c:v','libx264','-crf','15','-preset','medium',
      '-threads','4','-pix_fmt','yuv420p','-color_primaries:v','bt709','-color_trc:v','bt709',
      '-colorspace:v','bt709','-color_range','tv','-vf',
      'zscale=matrix=709:range=limited:primariesin=709:primaries=709:transferin=709:transfer=709',
      '-video_track_timescale','90000','-frames:v',String(range[1]-range[0]+1),path.join(out,'work',filename)],
      {stdio:['pipe','inherit','inherit'],cwd:path.dirname(encoder),
        env:{...process.env,DYLD_LIBRARY_PATH:path.dirname(encoder)}});
    merger.stdout.pipe(ffmpeg.stdin);
    const mergerExit = once(merger,'close'), encoderExit = once(ffmpeg,'close');
    let pipeError, exposures = 0;
    merger.stdin.on('error',error => {pipeError = error;});
    ffmpeg.stdin.on('error',error => {pipeError = error;});
    const write = async data => {
      if (pipeError) throw pipeError;
      if (!merger.stdin.write(data)) await once(merger.stdin,'drain');
    };
    const start = performance.now();
    try {
      for (let frame=range[0];frame<=range[1];frame++) {
        const f = frame/2;
        const still = f <= 1092 || f >= 1233 || (f>=1182 && f<1194);
        const fast = (f>=1120 && f<1147) || (f>=1198 && f<1226);
        const count = still ? 1 : fast ? 5 : 3;
        for (let i=0;i<count;i++) {
          // 180-degree shutter at 60 fps = 1/120 second = .25 design frames.
          const offset = count === 1 ? 0 : ((i+.5)/count-.5)*.25;
          const {buffer} = await shot(frame,offset);
          if (!buffer) throw new Error('Missing exposure buffer');
          const size = Buffer.alloc(4);size.writeUInt32BE(buffer.length);
          await write(size);await write(buffer);exposures++;
        }
        await write(Buffer.alloc(4));
        if ((frame-range[0])%30===0 || frame===range[1])
          console.log(`Ending ${frame-range[0]+1}/${range[1]-range[0]+1}; ${exposures} samples; ${Math.round((performance.now()-start)/1000)}s`);
      }
      merger.stdin.end();
      const [[mc],[fc]] = await Promise.all([mergerExit,encoderExit]);
      if (mc !== 0 || fc !== 0) throw new Error(`Merge=${mc}, encode=${fc}`);
    } catch (error) {merger.kill();ffmpeg.kill();throw error;}
    await writeFile(path.join(out,`reports/${filename}.json`),JSON.stringify({range,exposures,
      seconds:(performance.now()-start)/1000,shutterDegrees:180,shutterDesignFrames:.25,
      samples:[1,3,5],fps:60,scale:2,crf:15},null,2));
  } else {
    const benchmark = args.includes('--benchmark');
    const range = benchmark ? [120,179] : [0,2183];
    let last = -1;
    const start = performance.now();
    await renderMedia({composition,serveUrl,puppeteerInstance:browser,codec:'h264',
      pixelFormat:'yuv420p',crf:15,x264Preset:'medium',concurrency:2,imageFormat:'png',muted:true,
      scale:2,frameRange:range,colorSpace:'bt709',
      outputLocation:path.join(out,'work',benchmark ? 'benchmark-prefix.mp4' : 'prefix.mp4'),
      onProgress:({progress,renderedFrames,encodedFrames}) => {
        const step = Math.floor(progress*20);
        if (step>last) {last=step;console.log(`Prefix ${step*5}% (${renderedFrames} rendered, ${encodedFrames} encoded; ${Math.round((performance.now()-start)/1000)}s)`);}
      }});
    await writeFile(path.join(out,`reports/${benchmark ? 'benchmark' : 'prefix'}-render.json`),
      JSON.stringify({range,seconds:(performance.now()-start)/1000,fps:60,scale:2,crf:15,
        composition:composition.id,sourceHash:hash(await readFile(path.join(root,'src/FullFilmMaster.tsx')))},null,2));
  }
} finally {await browser.close({silent:true});}
