"""Average PNG exposure samples in linear light, streaming final PNGs to ffmpeg."""
import io
import struct
import sys

import numpy as np
from PIL import Image


def read_exact(size):
    data = bytearray()
    while len(data) < size:
        block = sys.stdin.buffer.read(size - len(data))
        if not block:
            raise EOFError("Truncated exposure sample")
        data.extend(block)
    return bytes(data)


def merge(samples):
    if len(samples) == 1:
        return samples[0]
    srgb = np.arange(256, dtype=np.float32) / 255
    lut = np.where(srgb <= .04045, srgb / 12.92, ((srgb + .055) / 1.055) ** 2.4)
    total = None
    for sample in samples:
        rgb = np.asarray(Image.open(io.BytesIO(sample)).convert("RGB"))
        value = lut[rgb]
        if total is None:
            total = value
        else:
            total += value
    linear = total / len(samples)
    result = np.where(linear <= .0031308, linear * 12.92,
                      1.055 * np.maximum(linear, 0) ** (1 / 2.4) - .055)
    pixels = np.clip(np.rint(result * 255), 0, 255).astype(np.uint8)
    output = io.BytesIO()
    Image.fromarray(pixels).save(output, format="PNG", compress_level=3)
    return output.getvalue()


def main():
    samples = []
    while header := sys.stdin.buffer.read(4):
        if len(header) != 4:
            raise EOFError("Truncated exposure header")
        size = struct.unpack(">I", header)[0]
        if size:
            samples.append(read_exact(size))
        else:
            if not samples:
                raise ValueError("Exposure has no samples")
            sys.stdout.buffer.write(merge(samples))
            sys.stdout.buffer.flush()
            samples.clear()
    if samples:
        raise EOFError("Unfinished exposure")


if __name__ == "__main__":
    main()
