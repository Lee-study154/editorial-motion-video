"""Small deterministic 48 kHz audio I/O and metering helpers."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import numpy as np

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
SR, DURATION, N = 48000, 43.2, 2073600


def run(args, payload=None):
    result = subprocess.run(list(map(str, args)), input=payload, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors="replace"))
    return result


def decode(path):
    raw = run(["ffmpeg", "-v", "error", "-i", path, "-ar", SR,
               "-ac", 2, "-f", "f32le", "-"]).stdout
    return np.frombuffer(raw, "<f4").reshape(-1, 2).astype(float)


def write(name, sound):
    assert sound.shape[1] == 2 and np.max(np.abs(sound)) < 1, name
    run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", SR,
         "-ac", 2, "-i", "-", "-c:a", "pcm_s24le", ROOT / name],
        sound.astype("<f4").tobytes())


def db(value):
    return float(20 * np.log10(max(float(value), 1e-12)))


def rms(sound):
    return float(np.sqrt(np.mean(sound ** 2)))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2) + "\n")


def meter(path):
    result = run(["ffmpeg", "-hide_banner", "-i", path, "-af",
                  "loudnorm=I=-17:TP=-1.5:LRA=8:print_format=json", "-f", "null", "-"])
    data = json.loads(re.findall(r"\{[^{}]+\}", result.stderr.decode())[-1])
    return {"integrated_lufs": float(data["input_i"]),
            "true_peak_dbtp": float(data["input_tp"]),
            "loudness_range_lu": float(data["input_lra"])}


def envelope(length, attack, release):
    env = np.ones(length)
    a, r = min(length, round(attack * SR)), min(length, round(release * SR))
    env[:a] = np.sin(np.linspace(0, np.pi / 2, a)) ** 2
    env[-r:] *= np.cos(np.linspace(0, np.pi / 2, r)) ** 2
    return env


def stereo(mono, pan=0):
    return mono[:, None] * np.sqrt([(1 - pan) / 2, (1 + pan) / 2])


def add(target, sound, start):
    begin = round(start * SR)
    assert begin >= 0
    count = min(len(sound), len(target) - begin)
    target[begin:begin + count] += sound[:count]
