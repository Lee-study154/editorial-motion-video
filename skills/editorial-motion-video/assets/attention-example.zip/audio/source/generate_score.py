"""Continuous original 18-bar score, extending the accepted six-bar palette."""
import numpy as np
from audio_utils import SR, N, write, envelope, stereo, add, dump, rms, db

RNG = np.random.default_rng(1542026)
BPM, BEAT, BAR = 100, .6, 2.4


def hz(midi):
    return 440 * 2 ** ((midi - 69) / 12)


def pad(notes, duration, pan):
    time = np.arange(round(duration * SR)) / SR
    result = np.zeros((len(time), 2))
    for index, note in enumerate(notes):
        freq, phase = hz(note), RNG.uniform(0, 2 * np.pi)
        mono = (np.sin(2 * np.pi * freq * time + .18 * np.sin(2 * np.pi * .17 * time) + phase)
                + .34 * np.sin(2 * np.pi * freq * 2.0015 * time + phase)
                + .10 * np.sin(2 * np.pi * freq * 3.0004 * time + phase))
        result += stereo(mono, np.clip(pan + (index - 1.5) * .18, -.8, .8))
    return result * envelope(len(time), .46, .8)[:, None] / len(notes)


def pluck(note, pan=0):
    time = np.arange(round(1.05 * SR)) / SR
    freq = hz(note)
    mono = (np.sin(2 * np.pi * freq * time)
            + .21 * np.sin(2 * np.pi * freq * 2 * time) * np.exp(-time * 5)
            + .055 * np.sin(2 * np.pi * freq * 3 * time) * np.exp(-time * 8))
    mono *= (1 - np.exp(-time * 130)) * np.exp(-time * 5)
    return stereo(mono * envelope(len(time), .016, .12) * .33, pan)


def tick():
    size = round(.075 * SR)
    noise = RNG.normal(size=size)
    freq = np.fft.rfftfreq(size, 1 / SR)
    shape = np.exp(-.5 * ((freq - 4650) / (3700 / 3)) ** 2)
    shape[freq < 120] = 0
    sound = np.fft.irfft(np.fft.rfft(noise) * shape, n=size)
    return sound / (np.std(sound) + 1e-12) * envelope(size, .014, .045)


music = np.zeros((N, 2))
chords = [[54, 57, 61, 64]] * 3 + [[55, 59, 62, 66], [54, 57, 61, 64], [57, 61, 64, 71]]
basses = [38, 42, 35, 31, 38, 33]
motifs = [[(.5, 74), (2, 78), (3, 76)], [(1, 73), (2.5, 76)],
          [(.5, 74), (2, 78), (3.5, 81)], [(1, 78), (3, 74)],
          [(.5, 76), (2, 78), (3, 74)], [(.5, 76), (2, 73)]]
for bar in range(18):
    index, start = bar % 6, bar * BAR
    add(music, pad(chords[index], BAR + .65, (-1) ** bar * .1) * .40, start)
    # Last section leaves more space; never restart a rendered loop.
    notes = motifs[index] if start < 31 else motifs[index][:1]
    for offset, note in notes:
        voice = pluck(note, (-1) ** (note + bar) * .42)
        when = start + offset * BEAT
        add(music, voice, when)
        add(music, voice[:, ::-1] * .24, when + BEAT * .75)
        add(music, voice * .095, when + BEAT * 1.5)
    for step in (range(4) if start < 31 else [0, 2]):
        time = np.arange(round(.36 * SR)) / SR
        freq = hz(basses[index])
        pulse = (np.sin(2 * np.pi * freq * time) + .18 * np.sin(2 * np.pi * freq * 2 * time))
        pulse *= envelope(len(time), .032, .23) * np.exp(-time * 5)
        add(music, stereo(pulse * (.29 if start >= 3.2 else .16)), start + step * BEAT)
    for step in ([1, 3, 5, 7] if start < 31 else [3]):
        add(music, stereo(tick() * .012, -.25), start + step * BEAT / 2)

music *= envelope(N, .30, 1.4)[:, None]
music *= 10 ** (-21 / 20) / rms(music)
write("music-original.wav", music)
dump("score.json", {"bpm": BPM, "bars": 18, "seed": 1542026,
     "duration_seconds": 43.2, "rms_dbfs": db(rms(music)),
     "synthesis": "Same pad harmonics, sine bass, pluck/delay and brushed ticks as accepted score",
     "continuity": "18 continuously overlapped synthesized bars, no concatenated audio loops",
     "late_arrangement": "After 31s: one pluck per bar, half bass pulses, one tick",
     "source": "Original procedural composition, no external melody/music samples"})
print("Generated original continuous score:", len(music), "samples/channel")
